<?php
// Check if the form is submitted and the 'url' field is set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
    $url = $_POST['url'];  // Capture the URL from the form input

    // Validate the URL to ensure it has a proper format
    if (filter_var($url, FILTER_VALIDATE_URL)) {
        // Attempt to fetch content from the provided URL (SSRF Vulnerability)
        $response = @file_get_contents($url);  // Suppress errors to prevent info leakage

        // Check if the content was fetched successfully
        if ($response !== false) {
            echo "<h2>Fetched Content:</h2>";
            echo "<pre>" . htmlspecialchars($response) . "</pre>";
        } else {
            echo "Failed to fetch content from the URL.";
        }
    } else {
        echo "Invalid URL!";
    }
} else {
    echo "<h2>Please provide a URL to fetch.</h2>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SSRF Vulnerability Demo</title>
</head>
<body>
    <h1>SSRF Vulnerability Demo</h1>
    
    <!-- Simple HTML Form to take the URL input -->
    <form action="" method="POST">
        <label for="url">Enter URL:</label>
        <input type="text" id="url" name="url" placeholder="http://example.com" required>
        <input type="submit" value="Fetch URL">
    </form>
    
</body>
</html>

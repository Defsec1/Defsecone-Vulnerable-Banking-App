<?php
// Start the session
session_start();

// Enable error reporting for debugging
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

// Check if the user is logged in and is an employee or admin

// Check if the user is logged in and has the correct role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');  // Redirect to login if not logged in or not an admin
    exit;
}


// Fetch the system stats using shell commands
$cpuUtilization = shell_exec("top -bn1 | grep 'Cpu(s)' | sed 's/.*, *\([0-9.]*\)%* id.*/\1/' | awk '{print 100 - $1}'");
$memUtilization = shell_exec("free | grep Mem | awk '{print $3/$2 * 100.0}'");
$diskUtilization = shell_exec("df -h / | grep / | awk '{ print $5 }'");
$systemTime = shell_exec("date");

// Strip any extra whitespace or newline characters
$cpuUtilization = trim($cpuUtilization);
$memUtilization = trim($memUtilization);
$diskUtilization = trim($diskUtilization);
$systemTime = trim($systemTime);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Dashboard</title>
  <style>
    /* Basic styling for the dashboard */
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      display: flex;
    }

    /* Sidebar */
    .sidebar {
      width: 250px;
      background-color: #003366;
      color: white;
      height: 100vh;
      position: fixed;
      padding-top: 30px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      color: #fff;
      text-align: center;
    }

    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      border-bottom: 1px solid #ccc;
    }

    .sidebar a:hover {
      background-color: #00509E;
    }

    .main-content {
      margin-left: 270px; /* Space for the sidebar */
      padding: 20px;
      width: calc(100% - 270px);
    }

    .container {
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    table, th, td {
      border: 1px solid #ddd;
    }

    th, td {
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #f2f2f2;
    }

    .logout-button {
      padding: 10px 20px;
      background-color: #003366;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .logout-button:hover {
      background-color: #002244;
    }

    .transaction-table {
      margin-top: 30px;
      width: 100%;
      border-collapse: collapse;
    }

    .transaction-table th, .transaction-table td {
      padding: 10px;
      border: 1px solid #ddd;
    }

    .transaction-table th {
      background-color: #f2f2f2;
    }

    /* Custom colors for debit and credit transaction types */
    .debit {
      color: #721c24; /* Red text color for debit */
    }

    .credit {
      color: #155724; /* Green text color for credit */
    }

    .system-stats {
      margin-top: 30px;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
    <div class="sidebar">
    <h3>Admin Dashboard</h3>
    <a href="dashboarda.php" class="active">Dashboard</a>
<a href="enum.php">User Management</a>    
<a href="tools.php">System Tools</a>
    <a href="logout.php">Logout</a>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="container">

      <!-- System Stats -->
      <div class="system-stats">
        <h3>System Resource Utilization</h3>
        <table>
          <tr>
            <th>CPU Utilization</th>
            <td><?php echo round($cpuUtilization, 2); ?>%</td>
          </tr>
          <tr>
            <th>Memory Utilization</th>
            <td><?php echo round($memUtilization, 2); ?>%</td>
          </tr>
          <tr>
            <th>Disk Utilization</th>
            <td><?php echo $diskUtilization; ?></td>
          </tr>
          <tr>
            <th>System Time</th>
            <td><?php echo $systemTime; ?></td>
          </tr>
        </table>
      </div>

      <br>
      <a href="logout.php">
        <button class="logout-button">Logout</button>
      </a>
    </div>
  </div>

</body>
</html>

<?php
session_start();

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Error and success messages
$error_message = '';
$success_message = '';

// Fetch logged-in user data
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Logged-in user ID
$sql_user = "SELECT * FROM users WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param('i', $user_id);
$stmt_user->execute();
$user_result = $stmt_user->get_result();

if ($user_result->num_rows > 0) {
    $user = $user_result->fetch_assoc();
} else {
    die("User not found.");
}

// Handle form submission for debit card application
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $card_type = $_POST['card_type'];
    $account_number = $_POST['account_number'];
    $aadhaar_card = $_FILES['aadhaar_card']['name'];

    // Validate form data
    if (empty($card_type) || empty($account_number) || empty($aadhaar_card)) {
        $error_message = 'Please fill all the fields and upload the Aadhaar card.';
    } else {
        // Generate unique filename for Aadhaar card upload
        $aadhaar_card_target = 'uploads/' . uniqid() . '-' . basename($aadhaar_card);
        
        // Validate and move the uploaded file
        if ($_FILES['aadhaar_card']['error'] != UPLOAD_ERR_OK) {
            $error_message = 'File upload failed with error code: ' . $_FILES['aadhaar_card']['error'];
        } elseif (move_uploaded_file($_FILES['aadhaar_card']['tmp_name'], $aadhaar_card_target)) {
            // Prepare the attachment link (file path)
            $attachment_link = $aadhaar_card_target;

            // Insert the service request into the database
            $status = 'In Progress';
            $reason = 'Fixed Deposit';

            $sql_request = "INSERT INTO service_requests (user_id, account_number, status, reason, attachment_link) 
                            VALUES (?, ?, ?, 'Debit', ?)";
            if ($stmt_request = $conn->prepare($sql_request)) {
                $stmt_request->bind_param('isss', $user_id, $account_number, $status, $attachment_link);
                if ($stmt_request->execute()) {
                    $success_message = 'Debit card application submitted successfully. Your request is in progress.';
                } else {
                    $error_message = 'Failed to submit your request. Please try again.';
                }
            } else {
                $error_message = 'Failed to prepare the query for service request.';
            }
        } else {
            $error_message = 'Failed to upload the Aadhaar card. Please try again.';
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply Debit Card</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f4f4f4;
        }
        .sidebar {
            width: 250px;
            background-color: #003366;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }
        .sidebar h3 {
            text-align: center;
            color: #fff;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            border-bottom: 1px solid #ccc;
        }
        .sidebar a:hover {
            background-color: #00509e;
        }
        .main-content {
            margin-left: 270px;
            padding: 20px;
        }
        .form-container {
            margin: 20px 0;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .error {
            color: red;
            font-weight: bold;
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .button {
            padding: 10px 20px;
            background-color: #003366;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }
        .button:hover {
            background-color: #002244;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>Dashboard</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="fundtransfer.php">Fund Transfer</a>
    <a href="fixeddeposit.php">Fixed Deposit</a>
    <a href="applydebitcard.php">Apply Debit Card</a>
    <a href="applycreditcard.php">Apply Credit Card</a>
    <a href="balance.php">Check Balance</a>
    <a href="statement.php">Account Statement</a>
    <a href="blockcard.php">Block Card</a>
    <a href="servicerequest.php">Service Request</a>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="form-container">
        <h2>Apply Debit Card</h2>

        <?php if ($error_message): ?>
            <p class="error"><?= $error_message ?></p>
        <?php elseif ($success_message): ?>
            <p class="success"><?= $success_message ?></p>
        <?php endif; ?>

        <form action="applydebitcard.php" method="POST" enctype="multipart/form-data">
            <label for="account_number">Account Number</label>
            <input type="text" id="account_number" name="account_number" value="<?= $user['account_number'] ?>" required><br><br>
            <label for="card_type">Card Type</label>
            <select id="card_type" name="card_type" required>
                <option value="platinum">Platinum</option>
                <option value="gold">Gold</option>
                <option value="silver">Silver</option>
            </select><br><br>
            <label for="aadhaar_card">Upload Aadhaar Card</label>
            <input type="file" id="aadhaar_card" name="aadhaar_card" required><br><br>
            <button type="submit" class="button">Apply for Debit Card</button>
        </form>
    </div>
</div>

</body>
</html>

<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in and if they are an employee
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employee') {
    // Redirect to login page or a forbidden page
    header('Location: forbidden.php');  // Redirect to a 403 Forbidden page
    exit();
}

// Database connection settings
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all service requests from the service_requests table
$sql = "SELECT service_id, user_id, account_number, status, reason, created_at, attachment_link
        FROM service_requests
        ORDER BY created_at DESC";  // Order requests by the creation time, descending
$result = $conn->query($sql);

// Update the status of a service request (approve or decline)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $service_id = $_POST['service_id'];  // Corrected key name to 'service_id'
    $status = $_POST['status'];  // 'approved' or 'declined'

    // Ensure status is either 'approved' or 'declined'
    if ($status == 'Completed' || $status == 'Failed') {
        $update_sql = "UPDATE service_requests SET status = ? WHERE service_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param('si', $status, $service_id);
        $stmt->execute();
        $stmt->close();
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #003366;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 30px;
            box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar h3 {
            color: #fff;
            text-align: center;
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 12px 20px;
            text-decoration: none;
            border-bottom: 1px solid #ccc;
        }

        .sidebar a:hover {
            background-color: #00509E;
        }

        .main-content {
            margin-left: 270px; /* Space for the sidebar */
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .form-button {
            padding: 5px 10px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-button:hover {
            background-color: #002244;
        }

        h2 {
            color: #333;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
     <div class="sidebar">
   <h3>Employee Dashboard</h3>
    <a href="dashboarde.php" class="active">Dashboard</a>
    <a href="createuser.php">Create User</a>
    <a href="manageusers.php">Manage Users</a>
    <a href="managemessage.php">Manage Messages</a>
   <a href="manageservice.php">Manage Service Request</a>    
<a href="logout.php">Logout</a>
</div>

    <!-- Main Content -->
    <div class="main-content">
        <h2>Service Requests</h2>

        <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Service ID</th>
                    <th>User ID</th>
                    <th>Account Number</th>
                    <th>Status</th>
                    <th>Reason</th>
                    <th>Created At</th>
                    <th>Attachment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($service_request = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $service_request['service_id']; ?></td>
                    <td><?php echo $service_request['user_id']; ?></td>
                    <td><?php echo $service_request['account_number']; ?></td>
                    <td><?php echo ucfirst($service_request['status']); ?></td>
                    <td><?php echo htmlspecialchars($service_request['reason']); ?></td>
                    <td><?php echo $service_request['created_at']; ?></td>
                    <td>
                        <?php if ($service_request['attachment_link']): ?>
                            <a href="<?php echo htmlspecialchars($service_request['attachment_link']); ?>" target="_blank">View Attachment</a>
                        <?php else: ?>
                            No Attachment
                        <?php endif; ?>
                    </td>
                    <td class="action-buttons">
                        <form method="POST" style="display: inline-block;">
                            <input type="hidden" name="service_id" value="<?php echo $service_request['service_id']; ?>">
                            <button type="submit" name="status" value="Completed" class="form-button">Approve</button>
                            <button type="submit" name="status" value="Failed" class="form-button">Decline</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
            <p>No service requests found.</p>
        <?php endif; ?>
    </div>

</body>
</html>

<?php
// Start the session
session_start();

// Database connection settings
$host = 'db';      // MySQL host (usually localhost)
$dbname = 'webserver';    // Database name
$dbusername = 'wp_user';  // The MySQL username
$dbpassword = 'your_password';  // The password for the MySQL user

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$passwordError = '';
$passwordSuccess = '';

// Handle password update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_password'], $_POST['confirm_password'])) {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Validate password fields
    if ($newPassword !== $confirmPassword) {
        $passwordError = "Passwords do not match!";
    } else {
        // Update the password in the database
        $email = $_SESSION['email']; // Get the email from session
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT); // Hash the password

        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashedPassword, $email);
        $stmt->execute();

        // Clear OTP session data after successful password update
        unset($_SESSION['otp']);
        unset($_SESSION['email']);
        unset($_SESSION['otp_sent']);

        $passwordSuccess = "Your password has been successfully updated.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <style>
        /* Basic styling for the page */
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }

        .container {
            width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        .error {
            color: red;
            font-weight: bold;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        form input {
            padding: 10px;
            font-size: 16px;
            width: 100%;
            margin: 10px 0;
        }

        form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Set New Password</h2>

    <!-- Display error message if password mismatch or any error occurs -->
    <?php if ($passwordError): ?>
        <div class="error"><?php echo $passwordError; ?></div>
    <?php endif; ?>

    <!-- Display success message for password change -->
    <?php if ($passwordSuccess): ?>
        <div class="success"><?php echo $passwordSuccess; ?></div>
    <?php endif; ?>

    <!-- New Password Form -->
    <form method="POST" action="">
        <label for="new_password">Enter new password:</label>
        <input type="password" id="new_password" name="new_password" required>

        <label for="confirm_password">Confirm new password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required>

        <button type="submit">Change Password</button>
    </form>
</div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>

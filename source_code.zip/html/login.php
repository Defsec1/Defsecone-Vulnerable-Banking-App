<?php
session_start();  // Start the session to store session variables

require_once 'vendor/autoload.php';  // Include Composer autoload
use \Firebase\JWT\JWT;

$secret_key = "123456";  // Secret key for JWT encoding and decoding

// Database connection settings
$host = 'db';  // Replace with your database host (use container name if using Docker)
$dbname = 'webserver';  // Database name
$username = 'wp_user';  // Replace with your database username
$password = 'your_password';  // Replace with your database password

// Create a PDO instance for MySQL connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}

$error_message = ''; // Default error message

// Check if form is submitted (POST request)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Prepare and execute query to fetch user data from the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username LIMIT 1");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verify if user exists and password matches
    if ($user && password_verify($password, $user['password'])) {
        // Prepare JWT payload
        $payload = [
            'iat' => time(),  // Issued at
            'exp' => time() + 3600,  // Expiration time (1 hour from now)
            'sub' => $username,  // Subject (user)
            'role' => $user['role'],  // Role (from database)
        ];

        // Encode the JWT token
        $jwt = JWT::encode($payload, $secret_key);

        // Return success response with JWT token and user role
        echo json_encode([
            'status' => 'success',
            'jwt' => $jwt,
            'role' => $user['role'],  // Return role along with token
        ]);
        exit;
    } else {
        // Invalid login
        echo json_encode([
            'status' => 'fail',
            'message' => 'Invalid username or password',
        ]);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <script src="https://cdn.jsdelivr.net/npm/crypto-js@4.1.1/core.js"></script> <!-- Ensure crypto-js is included properly -->
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #f7f7f7;
    }

    .container {
      display: flex;
      width: 70%;
      height: 80%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    .image-side {
      width: 50%;
      background-image: url('./login.jpg'); /* Replace with your image URL */
      background-size: cover;
      background-position: center;
      border-top-left-radius: 8px;
      border-bottom-left-radius: 8px;
    }

    .login-side {
      width: 50%;
      padding: 30px;
      background-color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      border-top-right-radius: 8px;
      border-bottom-right-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    button {
      width: 100%;
      padding: 10px;
      background-color: #003366; /* Dark blue color */
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    button:hover {
      background-color: #002244; /* Darker blue shade for hover effect */
    }

    .forgot-password {
      margin-top: 10px;
      font-size: 14px;
      color: #007BFF;
      text-decoration: none;
    }

    .forgot-password:hover {
      text-decoration: underline;
    }

    /* Error message style */
    .error-message {
      color: red;
      font-size: 14px;
      margin-top: 15px;
    }
  </style>
</head>
<body>

  <div class="container">
    <!-- Image side -->
    <div class="image-side"></div>

    <!-- Login form side -->
    <div class="login-side">
      <h2>Login</h2>

      <!-- Display error message if credentials are wrong -->
      <div id="errorMessage" class="error-message" style="display:none;"></div>

      <!-- Login Form -->
      <form id="loginForm">
        <div class="input-group">
          <input type="text" id="username" placeholder="Username" required>
        </div>
        <div class="input-group">
          <input type="password" id="password" placeholder="Password" required>
        </div>
        <button type="submit" id="loginButton">Login</button>
        <div id="loadingMessage" style="display:none;">Logging in...</div>
      </form>
  
      <a href="reset-request.php" class="forgot-password">Forgot Password?</a>
      <h2><center> This Page under development. All functionality may not work </center></h2>
    </div>
  </div>

  <script>
    document.querySelector('form').addEventListener('submit', function(event) {
      event.preventDefault();
      
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      const errorMessage = document.getElementById('errorMessage');

      errorMessage.style.display = 'none';  // Hide previous error message

      // Send login credentials to the server to authenticate and generate the token
      fetch(window.location.href, {  // The form submits to the same page
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          username: username,
          password: password
        })
      })
      .then(response => response.json())
      .then(data => {
        if (data.status === 'success') {
          // Save the JWT token in localStorage
          localStorage.setItem('jwtToken', data.jwt);
          
          // Send a GET request to hello.php with the token in the Authorization header
          fetch('./hello.php', {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${data.jwt}`  // Send the token here
            }
          })
          .then(response => response.json())
          .then(data => {
            if (data.status === 'success') {
              // Redirect based on role (admin or employee)
              window.location.href = data.redirect;  // Redirect to the correct dashboard
            } else {
              errorMessage.textContent = data.message;  // Show error message from hello.php
              errorMessage.style.display = 'block';
            }
          })
          .catch(error => {
            errorMessage.textContent = 'Error fetching hello.php';
            errorMessage.style.display = 'block';
            console.error('Error:', error);
          });
        } else {
          errorMessage.textContent = data.message;  // Show login error
          errorMessage.style.display = 'block';
        }
      })
      .catch(error => {
        errorMessage.textContent = 'An error occurred. Please try again.';
        errorMessage.style.display = 'block';
        console.error('Error:', error);
      });
    });
  </script>

</body>
</html>

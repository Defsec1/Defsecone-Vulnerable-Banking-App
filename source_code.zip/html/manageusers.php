<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'employee') {
    header('Location: login.php');  // Redirect to login page if not logged in
    exit();
}

// Database connection settings
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all users for display
$sql = "SELECT id, username, email, role, isactive FROM users WHERE role != 'admin'";
$result = $conn->query($sql);

// Handle updating user status (active/inactive)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $user_id = $_POST['user_id'];
    $isactive = isset($_POST['isactive']) ? 1 : 0;
    
    $update_sql = "UPDATE users SET isactive = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param('ii', $isactive, $user_id);
    $stmt->execute();
    header('Location: manageusers.php'); // Refresh the page after update
    exit();
}

// Handle user deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    
    $delete_sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    header('Location: manageusers.php'); // Refresh the page after deletion
    exit();
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $user_id = $_POST['user_id'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    $update_password_sql = "UPDATE users SET password = ? WHERE id = ?";
    $stmt = $conn->prepare($update_password_sql);
    $stmt->bind_param('si', $new_password, $user_id);
    $stmt->execute();
    header('Location: manageusers.php'); // Refresh the page after password change
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Users</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      margin: 0;
      display: flex;
    }

    /* Sidebar */
    .sidebar {
      width: 250px;
      background-color: #003366;
      color: white;
      height: 100vh;
      position: fixed;
      padding-top: 30px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      color: #fff;
      text-align: center;
    }

    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      border-bottom: 1px solid #ccc;
    }

    .sidebar a:hover {
      background-color: #00509E;
    }

    /* Main Content */
    .main-content {
      margin-left: 270px;
      padding: 20px;
      width: calc(100% - 270px);
    }

    .container {
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    table, th, td {
      border: 1px solid #ddd;
    }

    th, td {
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #f2f2f2;
    }

    .form-button {
      padding: 10px 20px;
      background-color: #003366;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .form-button:hover {
      background-color: #002244;
    }

    .status-checkbox {
      width: 50px;
      height: 30px;
    }

    /* Modal Styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgb(0, 0, 0);
      background-color: rgba(0, 0, 0, 0.4);
      padding-top: 60px;
    }

    .modal-content {
      background-color: #fff;
      margin: 5% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 50%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .modal-header, .modal-footer {
      padding: 10px;
    }

    .modal-footer {
      text-align: center;
    }

    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
    }

    .close:hover,
    .close:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
   <div class="sidebar">
   <h3>Employee Dashboard</h3>
    <a href="dashboarde.php" class="active">Dashboard</a>
    <a href="createuser.php">Create User</a>
    <a href="manageusers.php">Manage Users</a>
    <a href="managemessage.php">Manage Messages</a>
   <a href="manageservice.php">Manage Service Request</a>    
<a href="logout.php">Logout</a>
 </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="container">
      <h2>Manage Users</h2>
      
      <!-- Users Table -->
      <table>
        <thead>
          <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Active</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($user = $result->fetch_assoc()): ?>
            <tr>
              <td><?php echo $user['username']; ?></td>
              <td><?php echo $user['email']; ?></td>
              <td><?php echo ucfirst($user['role']); ?></td>
              <td>
                <form method="POST" style="display:inline;">
                  <input type="checkbox" name="isactive" <?php echo $user['isactive'] ? 'checked' : ''; ?> class="status-checkbox" onchange="this.form.submit()">
                  <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                  <input type="hidden" name="update_status">
                </form>
              </td>
              <td>
                <button class="form-button" onclick="openPasswordModal(<?php echo $user['id']; ?>)">Change Password</button>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                  <input type="hidden" name="delete_user">
                  <button class="form-button" type="submit" onclick="return confirm('Are you sure you want to delete this user?');">Delete</button>
                </form>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Change Password Modal -->
  <div id="passwordModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <span class="close" onclick="closePasswordModal()">&times;</span>
        <h2>Change Password</h2>
      </div>
      <div class="modal-body">
        <form method="POST">
          <input type="hidden" id="change_user_id" name="user_id">
          <label for="new_password">New Password:</label>
          <input type="password" id="new_password" name="new_password" required><br><br>
          <button type="submit" class="form-button" name="change_password">Submit</button>
        </form>
      </div>
    </div>
  </div>

  <script>
    function openPasswordModal(userId) {
      document.getElementById("passwordModal").style.display = "block";
      document.getElementById("change_user_id").value = userId;
    }

    function closePasswordModal() {
      document.getElementById("passwordModal").style.display = "none";
    }
  </script>

</body>
</html>

<?php
// Start the session (for user authentication)
session_start();

// Enable cross-origin sessions
ini_set('session.cookie_samesite', 'None');  // Allow cross-origin cookies
ini_set('session.cookie_secure', '1');      // Ensure cookies are only sent over HTTPS
ini_set('session.cookie_domain', '.defsecone.com');  // Allow cookies across subdomains

// Database credentials (replace with your actual values)
$host = 'db';      // Database server (usually 'localhost' or an IP address)
$dbname = 'webserver';    // Database name
$username = 'wp_user';    // Database username
$password = 'your_password';  // Database password

// Step 1: Establish a PDO connection
try {
    // Create a PDO instance for MySQL database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Set PDO error mode to exception (for better error handling)
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Optional: Set the charset to UTF-8 (to support wider characters like emojis)
    $pdo->exec("SET NAMES utf8mb4");
    
} catch (PDOException $e) {
    // If connection fails, display error message
    die("Connection failed: " . $e->getMessage());
}

// Step 2: Handle CORS if Origin header exists
if (isset($_SERVER['HTTP_ORIGIN'])) {
    // Allow CORS requests with credentials from a specific origin (not a wildcard *)
	$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (preg_match('/^http?:\/\/([a-z0-9-]+\.)*defsecone.*$/', $origin)){      
	header("Access-Control-Allow-Origin: $origin"); 
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Authorization");
        header("Access-Control-Allow-Credentials: true");
    } else {
        // If Origin is not allowed, return error
        echo json_encode([
            'status' => 'error',
            'message' => 'Origin not allowed.'
        ]);
        exit;
    }
}

// Step 3: Handle pre-flight OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    // Respond to pre-flight request
    exit;
}

// Step 4: Authenticate the user (check if the user is logged in using sessions)
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];  // Get the user ID from session

    try {
        // Step 5: Query the database to get the user's account balance
        $query = "SELECT username, balance FROM users WHERE id = :user_id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();

        // Fetch the result
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            // If user exists, return account balance and username as HTML table
            echo "<html><head><title>User Account Details</title><style>
                    table { width: 50%; border-collapse: collapse; margin: 20px 0; }
                    th, td { padding: 10px; text-align: center; border: 1px solid #ddd; }
                    tr:nth-child(even) { background-color: #f2f2f2; }
                  </style></head><body>";
            echo "<h1>Account Information</h1>";
            echo "<table>";
            echo "<tr><th>Username</th><th>Account Balance</th></tr>";
            echo "<tr><td>" . htmlspecialchars($result['username']) . "</td><td>" . htmlspecialchars($result['balance']) . "</td></tr>";
            echo "</table>";
            echo "</body></html>";
        } else {
            // If user not found
            echo "<html><body><h1>User not found.</h1></body></html>";
        }
    } catch (PDOException $e) {
        // Handle database query errors
        echo "<html><body><h1>Error: " . htmlspecialchars($e->getMessage()) . "</h1></body></html>";
    }
} else {
    // If the user is not authenticated (session not found)
    echo "<html><body><h1>User not authenticated.</h1></body></html>";
}
?>
<!-- The URL can be accessed from various subdomains since it is required as part of business requirement for subdomain to access pls use accountstatement.html -->

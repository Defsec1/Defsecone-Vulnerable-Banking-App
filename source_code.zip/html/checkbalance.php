<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header("Location: login.php");
    exit();
}

// Database connection settings
$host = 'db';      // MySQL host (usually localhost)
$dbname = 'webserver';    // Database name
$dbusername = 'wp_user';  // The MySQL username
$dbpassword = 'your_password';  // The password for the MySQL user

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error_message = '';
$balance = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the entered account number
    $account_number = isset($_POST['account_number']) ? $_POST['account_number'] : '';

    // Sanitize input (for security)
    $account_number = $conn->real_escape_string($account_number);

    // Check if account number is provided
    if (empty($account_number)) {
        $error_message = 'Please enter an account number.';
    } else {
        // Get the user_id from session
        $user_id = $_SESSION['user_id'];

        // Query to check if the account number matches the logged-in user's account
        $sql = "SELECT * FROM users WHERE id = ? AND account_number = ? LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('is', $user_id, $account_number);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            // Account found, fetch balance
            $user = $result->fetch_assoc();
            $balance = $user['balance'];
        } else {
            // Account number does not match the logged-in user's account
            $error_message = "The account number '$account_number' does not exist or does not match your account.";
        }

        // Close statement
        $stmt->close();
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      margin: 0;
      display: flex;
    }

    /* Sidebar */
    .sidebar {
      width: 250px;
      background-color: #003366;
      color: white;
      height: 100vh;
      position: fixed;
      padding-top: 30px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      color: #fff;
      text-align: center;
    }

    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      border-bottom: 1px solid #ccc;
    }

    .sidebar a:hover {
      background-color: #00509E;
    }

    .sidebar a.active {
      background-color: #00509E;
    }

    /* Main Content */
    .main-content {
      margin-left: 270px;
      padding: 20px;
      width: calc(100% - 270px);
    }

    .container {
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    /* Result Container */
    .result-container {
      margin-top: 30px;
    }

    /* Form Styling */
    form {
      margin-bottom: 20px;
    }

    form input {
      padding: 8px;
      font-size: 16px;
      width: 250px;
      margin-right: 10px;
    }

    form button {
      padding: 8px 16px;
      font-size: 16px;
      background-color: #007bff;
      color: white;
      border: none;
      cursor: pointer;
    }

    form button:hover {
      background-color: #0056b3;
    }

    /* Preformatted Output Styling */
    pre {
      background-color: #f1f1f1;
      padding: 10px;
      border-radius: 4px;
      border: 1px solid #ccc;
      font-size: 14px;
      white-space: pre-wrap;
      word-wrap: break-word;
    }

    /* System Time Section */
    .system-time {
      margin-top: 30px;
      font-size: 18px;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
   <div class="sidebar">
      <h3>Dashboard</h3>
    <a href="fundtransfer.php">Fund Transfer</a>
    <a href="fixeddeposit.php">Fixed Deposit</a>
    <a href="applydebitcard.php">Apply Debit Card</a>
    <a href="applycreditcard.php">Apply Credit Card</a>
    <a href="checkbalance.php">Check Balance</a>
    <a href="accountstatement.php">Account Statement</a>
    <a href="blockcard.php">Block Card</a>
    <a href="servicerequest.php">Service Request</a>
  </div>
    
<div class="main-content">

<div class="container">
    <h2>Check Account Balance</h2>

    <?php if ($error_message): ?>
        <div class="error-message"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <?php if ($balance !== ''): ?>
        <div class="balance-message">
            Your balance is: $<?php echo number_format($balance, 2); ?>
        </div>
    <?php endif; ?>

    <form action="checkbalance.php" method="POST">
        <div class="input-group">
            <label for="account_number">Enter Your Account Number</label>
            <input type="text" id="account_number" name="account_number" required>
        </div>

        <button type="submit" class="button">Check Balance</button>
    </form>
</div>

</body>
</html>

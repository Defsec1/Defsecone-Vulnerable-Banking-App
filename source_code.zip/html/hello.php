<?php
session_start();  // Start the session to store session variables

require_once 'vendor/autoload.php';  // Make sure to include Composer autoload
use \Firebase\JWT\JWT;

$secret_key = "123456";  // Secret key for JWT encoding and decoding

// Check if Authorization header is present
if (!isset($_SERVER['HTTP_AUTHORIZATION'])) {
    echo json_encode(['status' => 'fail', 'message' => 'Authorization header not found.']);
    exit;
}

// Get the JWT token from the Authorization header
$auth_header = $_SERVER['HTTP_AUTHORIZATION'];
$jwt = str_replace('Bearer ', '', $auth_header);

// Decode the JWT token
try {
    $decoded = JWT::decode($jwt, $secret_key, ['HS256']);
    
    // Set the session variables
    $_SESSION['username'] = $decoded->sub;  // The username (subject)
    $_SESSION['role'] = $decoded->role;  // The role

    // Redirect based on user role
    if ($_SESSION['role'] === 'admin') {
        echo json_encode(['status' => 'success', 'redirect' => 'dashadmin.php']);
    } else {
        echo json_encode(['status' => 'success', 'redirect' => 'dashemp.php']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'fail', 'message' => 'Invalid or expired token.']);
}
?>

<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in and is an employee
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');  // Redirect to login page if not logged in
    exit();
}

// Database connection settings
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user data based on session
$user_id = $_SESSION['user_id'];
$sql = "SELECT id, username, email, account_number, balance, role, isactive, created_at FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if user exists
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    die("User not found.");
}

// Check if the user is an employee for managing users
$is_employee = ($user['role'] == 'employee');

// Fetch all users (for employee users)
if ($is_employee) {
    $sql_users = "SELECT id, username, email, account_number, balance, isactive FROM users ORDER BY created_at DESC";
    $stmt_users = $conn->prepare($sql_users);
    $stmt_users->execute();
    $users = $stmt_users->get_result();
}

// Fetch transaction history for the logged-in user
$sql_transactions = "SELECT * FROM transactions WHERE user_id = ? ORDER BY transaction_date DESC"; // Use transaction_date
$stmt_transactions = $conn->prepare($sql_transactions);
$stmt_transactions->bind_param('i', $user_id);
$stmt_transactions->execute();
$transactions = $stmt_transactions->get_result();

// Fetch messages and service requests (if employee)
$messages = null;
$service_requests = null;
if ($is_employee) {
    $sql_messages = "SELECT id, user_id, description, created_at FROM messages ORDER BY created_at DESC";
    $stmt_messages = $conn->prepare($sql_messages);
    $stmt_messages->execute();
    $messages = $stmt_messages->get_result();

    $sql_service_requests = "SELECT service_id, user_id, reason, status FROM service_requests ORDER BY created_at DESC";
    $stmt_service_requests = $conn->prepare($sql_service_requests);
    $stmt_service_requests->execute();
    $service_requests = $stmt_service_requests->get_result();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Dashboard</title>
  <style>
    /* Basic styling for the dashboard */
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      display: flex;
    }

    /* Sidebar */
    .sidebar {
      width: 250px;
      background-color: #003366;
      color: white;
      height: 100vh;
      position: fixed;
      padding-top: 30px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      color: #fff;
      text-align: center;
    }

    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      border-bottom: 1px solid #ccc;
    }

    .sidebar a:hover {
      background-color: #00509E;
    }

    .main-content {
      margin-left: 270px; /* Space for the sidebar */
      padding: 20px;
      width: calc(100% - 270px);
    }

    .container {
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    table, th, td {
      border: 1px solid #ddd;
    }

    th, td {
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #f2f2f2;
    }

    .logout-button {
      padding: 10px 20px;
      background-color: #003366;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .logout-button:hover {
      background-color: #002244;
    }

    .transaction-table {
      margin-top: 30px;
      width: 100%;
      border-collapse: collapse;
    }

    .transaction-table th, .transaction-table td {
      padding: 10px;
      border: 1px solid #ddd;
    }

    .transaction-table th {
      background-color: #f2f2f2;
    }

    /* Custom colors for debit and credit transaction types */
    .debit {
      color: #721c24; /* Red text color for debit */
    }

    .credit {
      color: #155724; /* Green text color for credit */
    }

    /* Style for form and user management */
    .user-form input, .user-form select {
      padding: 8px;
      margin: 10px 0;
      width: 100%;
      border-radius: 4px;
      border: 1px solid #ddd;
    }
    .user-form button {
      padding: 10px 20px;
      background-color: #003366;
      color: white;
      border: none;
      border-radius: 4px;
    }
    .user-form button:hover {
      background-color: #002244;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h3>Dashboard</h3>
    <?php if ($is_employee): ?>
      <a href="createuser.php">Create User</a>
      <a href="enableuser.php">Enable User</a>
      <a href="messages.php">Review Messages</a>
      <a href="servicerequest.php">Review Service Requests</a>
    <?php endif; ?>
    <a href="fundtransfer.php">Fund Transfer</a>
    <a href="fixeddeposit.php">Fixed Deposit</a>
    <a href="applydebitcard.php">Apply Debit Card</a>
    <a href="applycreditcard.php">Apply Credit Card</a>
    <a href="checkbalance.php">Check Balance</a>
    <a href="accountstatement.php">Account Statement</a>
    <a href="blockcard.php">Block Card</a>
    <a href="servicerequest.php">Service Request</a>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="container">
      <h2>Welcome, <?php echo $user['username']; ?></h2>

      <table>
        <tr>
          <th>Username</th>
          <td><?php echo $user['username']; ?></td>
        </tr>
        <tr>
          <th>Email</th>
          <td><?php echo $user['email']; ?></td>
        </tr>
        <tr>
          <th>Account Number</th>
          <td><?php echo $user['account_number']; ?></td>
        </tr>
        <tr>
          <th>Balance</th>
          <td>₹<?php echo number_format($user['balance'], 2); ?></td>
        </tr>
        <tr>
          <th>Role</th>
          <td><?php echo ucfirst($user['role']); ?></td>
        </tr>
        <tr>
          <th>Status</th>
          <td><?php echo $user['isactive'] ? 'Active' : 'Inactive'; ?></td>
        </tr>
        <tr>
          <th>Account Created</th>
          <td><?php echo $user['created_at']; ?></td>
        </tr>
      </table>

      <!-- Transaction History Table -->
      <h3>Transaction History</h3>
      <?php if ($transactions->num_rows > 0): ?>
        <table class="transaction-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Transaction Type</th>
              <th>Amount (₹)</th>
              <th>Balance After</th>
              <th>Destination Account</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($transaction = $transactions->fetch_assoc()): ?>
              <tr>
                <td><?php echo $transaction['transaction_date']; ?></td>
                <td class="<?php echo ($transaction['transaction_type'] == 'debit') ? 'debit' : 'credit'; ?>">
                  <?php echo ucfirst($transaction['transaction_type']); ?>
                </td>
                <td><?php echo number_format($transaction['amount'], 2); ?></td>
                <td><?php echo number_format($transaction['balance_after'], 2); ?></td>
                <td><?php echo $transaction['destination_account']; ?></td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      <?php else: ?>
        <p>No transactions found.</p>
      <?php endif; ?>

      <!-- Logout Button -->
      <br>
      <a href="logout.php">
        <button class="logout-button">Logout</button>
      </a>
    </div>
  </div>

</body>
</html>

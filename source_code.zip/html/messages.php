<?php
// Start the session
session_start();

// Database connection settings
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Declare error variables
$name_err = $phone_err = $email_err = $description_err = "";
$name = $phone = $email = $description = "";
$success_message = "";

// Check if the user is logged in and user_id exists in session
if (!isset($_SESSION['user_id'])) {
    die("You must be logged in to submit a message.");
}

// Get the user_id from the session
$user_id = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Sanitize input and validate
    if (empty($_POST['name'])) {
        $name_err = "Name is required.";
    } else {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
    }

    if (empty($_POST['phone_number'])) {
        $phone_err = "Phone number is required.";
    } else {
        $phone = mysqli_real_escape_string($conn, $_POST['phone_number']);
    }

    if (empty($_POST['email'])) {
        $email_err = "Email is required.";
    } else {
        $email = mysqli_real_escape_string($conn, $_POST['email']);
    }

    if (empty($_POST['description'])) {
        $description_err = "Description is required.";
    } else {
        $description = mysqli_real_escape_string($conn, $_POST['description']);
    }

    // If no errors, insert into database
    if (empty($name_err) && empty($phone_err) && empty($email_err) && empty($description_err)) {
        // Prepare SQL statement to insert the message, including user_id
        $sql = "INSERT INTO messages (user_id, name, phone_number, email, description) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issss", $user_id, $name, $phone, $email, $description);

        if ($stmt->execute()) {
            // If message is inserted successfully, set success message
            $success_message = "Message submitted successfully!";
            // Optionally, you can redirect to another page after submission
            // header("Location: messages.php"); exit;
        } else {
            $success_message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }

    // Close the connection after use
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit a Message</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
            display: flex;
        }
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: #003366;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 30px;
            box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar h3 {
            color: #fff;
            text-align: center;
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 12px 20px;
            text-decoration: none;
            border-bottom: 1px solid #ccc;
        }

        .sidebar a:hover {
            background-color: #00509E;
        }

        .main-content {
            margin-left: 270px; /* Space for the sidebar */
            padding: 20px;
            width: calc(100% - 270px);
        }

        .container {
            width: 60%;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"], input[type="email"], textarea {
            margin: 10px 0;
            padding: 10px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }

        textarea {
            resize: vertical;
            height: 150px;
        }

        .form-error {
            color: red;
            font-size: 14px;
        }

        .submit-btn {
            padding: 12px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #002244;
        }

        .success-message {
            color: green;
            font-size: 16px;
            text-align: center;
        }

        .error-message {
            color: red;
            font-size: 16px;
            text-align: center;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
    <h3>Dashboard</h3>
    <a href="fundtransfer.php">Fund Transfer</a>
    <a href="fixeddeposit.php">Fixed Deposit</a>
    <a href="applydebitcard.php">Apply Debit Card</a>
    <a href="applycreditcard.php">Apply Credit Card</a>
    <a href="checkbalance.php">Check Balance</a>
    <a href="accountstatement.php">Account Statement</a>
    <a href="blockcard.php">Block Card</a>
    <a href="servicerequest.php">Service Request</a>
</div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <h2>Submit a Message</h2>
            
            <!-- Display Success or Error Message -->
            <?php if (!empty($success_message)): ?>
                <p class="success-message"><?php echo $success_message; ?></p>
            <?php elseif (!empty($name_err) || !empty($phone_err) || !empty($email_err) || !empty($description_err)): ?>
                <p class="error-message">Please fix the errors and try again.</p>
            <?php endif; ?>

            <form method="POST" action="">

                <!-- Name -->
                <label for="name">Name:</label>
                <input type="text" name="name" id="name" value="<?php echo isset($name) ? $name : ''; ?>">
                <span class="form-error"><?php echo $name_err; ?></span>

                <!-- Phone Number -->
                <label for="phone_number">Phone Number:</label>
                <input type="text" name="phone_number" id="phone_number" value="<?php echo isset($phone) ? $phone : ''; ?>">
                <span class="form-error"><?php echo $phone_err; ?></span>

                <!-- Email -->
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="<?php echo isset($email) ? $email : ''; ?>">
                <span class="form-error"><?php echo $email_err; ?></span>

                <!-- Description -->
                <label for="description">Message Description:</label>
                <textarea name="description" id="description"><?php echo isset($description) ? $description : ''; ?></textarea>
                <span class="form-error"><?php echo $description_err; ?></span>

                <!-- Submit Button -->
                <button type="submit" class="submit-btn">Submit Message</button>
            </form>
        </div>
    </div>

</body>
</html>

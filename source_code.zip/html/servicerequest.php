<?php
session_start();

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Error and success messages
$error_message = '';
$success_message = '';

// Fetch logged-in user data
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Logged-in user ID

// Fetch existing service requests for the user
$sql_service_requests = "SELECT * FROM service_requests WHERE user_id = ? ORDER BY created_at DESC";
$stmt_service_requests = $conn->prepare($sql_service_requests);
$stmt_service_requests->bind_param('i', $user_id);
$stmt_service_requests->execute();
$result_service_requests = $stmt_service_requests->get_result();

// Handle form submission for new message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message_submit'])) {
    // Get form data
    $name = $_POST['name'];
    $phone_number = $_POST['phone_number'];
    $email = $_POST['email'];
    $description = $_POST['description'];

    // Validate form data
    if (empty($name) || empty($phone_number) || empty($email) || empty($description)) {
        $error_message = 'Please fill all the fields.';
    } else {
        // Insert the message into the database
        $sql_message = "INSERT INTO messages (user_id, name, phone_number, email, description) 
                        VALUES (?, ?, ?, ?, ?)";
        if ($stmt_message = $conn->prepare($sql_message)) {
            $stmt_message->bind_param('issss', $user_id, $name, $phone_number, $email, $description);
            if ($stmt_message->execute()) {
                $success_message = 'Your message has been submitted successfully.';
            } else {
                $error_message = 'Failed to submit your message. Please try again.';
            }
        } else {
            $error_message = 'Failed to prepare the query for message submission.';
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f4f4f4;
        }
        .sidebar {
            width: 250px;
            background-color: #003366;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }
        .sidebar h3 {
            text-align: center;
            color: #fff;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            border-bottom: 1px solid #ccc;
        }
        .sidebar a:hover {
            background-color: #00509e;
        }
        .main-content {
            margin-left: 270px;
            padding: 20px;
        }
        .form-container, .service-requests-container {
            margin: 20px 0;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .error {
            color: red;
            font-weight: bold;
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .button {
            padding: 12px 25px;
            background-color: #003366;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
        }
        .button:hover {
            background-color: #002244;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
        }
        form input, form textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        form textarea {
            resize: vertical;
            height: 150px;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>Dashboard</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="fundtransfer.php">Fund Transfer</a>
    <a href="fixeddeposits.php">Fixed Deposit</a>
    <a href="applydebitcard.php">Apply Debit Card</a>
    <a href="applycreditcard.php">Apply Credit Card</a>
    <a href="balance.php">Check Balance</a>
    <a href="statement.php">Account Statement</a>
    <a href="blockcard.php">Block Card</a>
    <a href="servicerequest.php">Service Request</a>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="form-container">
        <h2>Service Request Status</h2>

        <?php if ($error_message): ?>
            <p class="error"><?= $error_message ?></p>
        <?php elseif ($success_message): ?>
            <p class="success"><?= $success_message ?></p>
        <?php endif; ?>

        <h3>Your Existing Service Requests:</h3>
        <table>
            <tr>
                <th>Service ID</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Created At</th>
            </tr>
            <?php while ($request = $result_service_requests->fetch_assoc()): ?>
                <tr>
                    <td><?= $request['service_id'] ?></td>
                    <td><?= $request['reason'] ?></td>
                    <td><?= $request['status'] ?></td>
                    <td><?= $request['created_at'] ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <div class="form-container">
        <h2>Submit a New Message</h2>
        <form action="servicerequest.php" method="POST">
            <label for="name">Your Name</label>
            <input type="text" id="name" name="name" required><br><br>

            <label for="phone_number">Phone Number</label>
            <input type="text" id="phone_number" name="phone_number" required><br><br>

            <label for="email">Email ID</label>
            <input type="email" id="email" name="email" required><br><br>

            <label for="description">Description</label>
            <textarea id="description" name="description" required></textarea><br><br>

            <button type="submit" name="message_submit" class="button">Submit Message</button>
        </form>
    </div>
</div>

</body>
</html>

<?php
// Start the session
session_start();

// Database connection settings
$host = 'db';      // MySQL host
$dbname = 'webserver';    // Database name
$dbusername = 'wp_user';  // MySQL username
$dbpassword = 'your_password';  // MySQL password

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$emailError = '';
$otpSent = false;
$otp = '';
$otpError = '';

// Handle the forgot password form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = $_POST['email'];

    // Sanitize and validate email
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Check if email exists in the database
        $stmt = $conn->prepare("SELECT role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // User found, get the role and set it in the session
            $user = $result->fetch_assoc();
            $_SESSION['email'] = $email;  // Store email in session
            $_SESSION['role'] = $user['role'];  // Store user role in session
            
            // Generate a random OTP
            $otp = rand(100000, 999999);  // 6-digit OTP
            $_SESSION['otp'] = $otp;  // Store OTP in session
            $_SESSION['otp_sent'] = true;  // Flag to indicate OTP was sent
            
            // For demonstration, we will output the OTP on the screen
            // You can modify this to send the OTP via email in real scenarios
           // echo "Your OTP is: $otp";  // Display the OTP for demonstration
            
            // Redirect to OTP validation page
            header("Location: validate_otp.php");
            exit();
        } else {
            $emailError = "Email address not found.";
        }
    } else {
        $emailError = "Please enter a valid email address.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        /* Basic styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }

        .container {
            width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        .error {
            color: red;
            font-weight: bold;
        }

        form input {
            padding: 10px;
            font-size: 16px;
            width: 100%;
            margin: 10px 0;
        }

        form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Forgot Password</h2>

    <!-- Display error message if email is not found or invalid -->
    <?php if ($emailError): ?>
        <div class="error"><?php echo $emailError; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="email">Enter your email address:</label>
        <input type="email" id="email" name="email" required>

        <button type="submit">Send OTP</button>
    </form>
</div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>

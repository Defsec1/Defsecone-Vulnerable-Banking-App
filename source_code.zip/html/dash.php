<?php
session_start();  // Start the session to access session variables

// Check if the user is logged in and has the correct role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');  // Redirect to login if not logged in or not an admin
    exit;
}

echo "<h1>Welcome, " . $_SESSION['username'] . "!</h1>";
echo "<p>You are logged in as an admin.</p>";
?>

<!-- Dashboard Content for Admin -->
<a href="dashboarda.php">Go to Admin Dashboard</a>


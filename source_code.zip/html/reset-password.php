<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection (adjust to your DB details)
$host = 'db';
$dbname = 'webserver';
$username = 'wp_user';
$password = 'your_password';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Step 1: Get the token from the URL
$token = $_GET['token'];  // Assuming the token is passed in the URL

if (!$token) {
    echo "Invalid token.";
    exit;
}

// Step 2: Verify the token from the database
$sql = "SELECT * FROM password_resets WHERE token = :token";
$stmt = $pdo->prepare($sql);
$stmt->execute([':token' => $token]);
$reset_request = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reset_request) {
    echo "Invalid or expired token.";
    exit;
}

// Step 3: Token is valid, show the password reset form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and update the new password
    $new_password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Check if passwords match
    if ($new_password !== $confirm_password) {
        echo "Passwords do not match.";
        exit;
    }

    // Hash the new password
    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

    // Update the password in the users table (assuming the email is unique)
    $sql = "UPDATE users SET password = :password WHERE email = :email";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':password' => $hashed_password,
        ':email' => $reset_request['email'],
    ]);

    // Optional: Delete the reset token from the password_resets table after use
    $sql = "DELETE FROM password_resets WHERE token = :token";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':token' => $token]);

    echo "Password reset successful!";
    exit;
}
?>

<!-- HTML Form to reset the password -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            color: #007BFF;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        label {
            font-weight: bold;
            font-size: 1rem;
            color: #333;
        }
        input[type="password"] {
            padding: 12px;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
        }
        button {
            padding: 12px 20px;
            background-color: #007BFF;
            color: #fff;
            font-size: 1rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            margin-top: 20px;
            color: #ff0000;
        }
        .info {
            text-align: center;
            margin-top: 20px;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Reset Your Password</h2>

    <!-- Password reset form -->
    <form method="POST">
        <div class="form-group">
            <label for="password">New Password:</label>
            <input type="password" id="password" name="password" required>
        </div>

        <div class="form-group">
            <label for="confirm_password">Confirm New Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>

        <button type="submit">Reset Password</button>
    </form>
</div>

</body>
</html>

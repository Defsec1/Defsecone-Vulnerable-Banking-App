<?php
session_start(); // Start the session to retrieve user data

// Database connection
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Error and success messages
$error_message = '';
$success_message = '';

// Fetch logged-in user data
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Logged-in user ID
$sql_user = "SELECT * FROM users WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param('i', $user_id);
$stmt_user->execute();
$user_result = $stmt_user->get_result();

if ($user_result->num_rows > 0) {
    $user = $user_result->fetch_assoc();
} else {
    die("User not found.");
}

// Handle form submission for fund transfer
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get POST data (source account will be passed as hidden data)
    $source_account = $_POST['source_account']; // Source account from hidden field
    $destination_account = $_POST['destination_account'];
    $amount = $_POST['amount'];

    // Validate inputs
    if (empty($destination_account) || empty($amount) || !is_numeric($amount)) {
        $error_message = 'Please provide a valid destination account number and amount.';
    } else if ($user['balance'] < $amount) {
        $error_message = 'Insufficient balance for this transfer.';
    } else {
        // Begin transaction (for consistency)
        $conn->begin_transaction();

        try {
            // Update source account balance (subtract amount)
            $new_source_balance = $user['balance'] - $amount;
            $sql_source_update = "UPDATE users SET balance = ? WHERE account_number = ?";
            $stmt_source = $conn->prepare($sql_source_update);
            $stmt_source->bind_param('ds', $new_source_balance, $source_account);
            if (!$stmt_source->execute()) {
                throw new Exception("Failed to update source account balance.");
            }

            // Check if destination account exists and get balance
            $sql_dest_check = "SELECT balance FROM users WHERE account_number = ?";
            $stmt_dest_check = $conn->prepare($sql_dest_check);
            $stmt_dest_check->bind_param('s', $destination_account);
            $stmt_dest_check->execute();
            $result_dest = $stmt_dest_check->get_result();

            if ($result_dest->num_rows > 0) {
                $destination = $result_dest->fetch_assoc();
                $new_dest_balance = $destination['balance'] + $amount;

                // Update destination account balance (add amount)
                $sql_dest_update = "UPDATE users SET balance = ? WHERE account_number = ?";
                $stmt_dest_update = $conn->prepare($sql_dest_update);
                $stmt_dest_update->bind_param('ds', $new_dest_balance, $destination_account);
                if (!$stmt_dest_update->execute()) {
                    throw new Exception("Failed to update destination account balance.");
                }

                // Insert transaction record for the source account (debit)
                $transaction_sql = "INSERT INTO transactions (user_id, transaction_type, amount, balance_after, destination_account, source_account, transaction_date) 
                                    VALUES (?, 'debit', ?, ?, ?, ?, NOW())";
                $stmt_transaction = $conn->prepare($transaction_sql);
                $stmt_transaction->bind_param('iddss', $user_id, $amount, $new_source_balance, $destination_account, $source_account);
                if (!$stmt_transaction->execute()) {
                    throw new Exception("Failed to record source transaction.");
                }

                // Insert transaction record for the destination account (credit)
                $transaction_sql_dest = "INSERT INTO transactions (user_id, transaction_type, amount, balance_after, source_account, transaction_date) 
                                    VALUES (?, 'credit', ?, ?, ?, NOW())";
                $stmt_transaction_dest = $conn->prepare($transaction_sql_dest);
                $stmt_transaction_dest->bind_param('idds', $user_id, $amount, $new_dest_balance, $source_account);
                if (!$stmt_transaction_dest->execute()) {
                    throw new Exception("Failed to record destination transaction.");
                }

                // Commit the transaction
                $conn->commit();
                $success_message = 'Transfer successful!';
            } else {
                $error_message = 'Destination account not found.';
            }
        } catch (Exception $e) {
            // Rollback the transaction in case of an error
            $conn->rollback();
            $error_message = 'Error: ' . $e->getMessage();
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fund Transfer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        button {
            background-color: #003366;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #00509e;
        }

        .message {
            font-size: 16px;
            color: red;
            text-align: center;
        }

        .success-message {
            color: green;
        }

        .sidebar {
            width: 250px;
            background-color: #003366;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 30px;
            box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar h3 {
            color: #fff;
            text-align: center;
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 12px 20px;
            text-decoration: none;
            border-bottom: 1px solid #ccc;
        }

        .sidebar a:hover {
            background-color: #00509E;
        }
    </style>
</head>
<body>

    <!-- Sidebar (Navigation) -->
    <div class="sidebar">
        <h3>Dashboard</h3>
        <a href="fundtransfer.php">Fund Transfer</a>
        <a href="#">Fixed Deposit</a>
        <a href="#">Apply Debit Card</a>
        <a href="#">Apply Credit Card</a>
        <a href="#">Check Balance</a>
        <a href="#">Account Statement</a>
        <a href="#">Block Card</a>
        <a href="#">Service Request</a>
    </div>

    <!-- Main Content -->
    <div class="container">
        <h2>Fund Transfer</h2>

        <?php if ($error_message): ?>
            <div class="message"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <?php if ($success_message): ?>
            <div class="message success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <!-- Fund Transfer Form -->
        <form method="POST" action="transfer.php">
            <input type="hidden" name="source_account" value="<?php echo $user['account_number']; ?>">

            <div class="form-group">
                <label for="destination_account">Destination Account Number</label>
                <input type="text" id="destination_account" name="destination_account" required>
            </div>

            <div class="form-group">
                <label for="amount">Amount</label>
                <input type="number" id="amount" name="amount" required min="1">
            </div>

            <button type="submit">Transfer</button>
        </form>
    </div>

</body>
</html>

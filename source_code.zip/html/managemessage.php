<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in and if they are an employee
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page or a forbidden page
    header('Location: forbidden.php');  // Redirect to a 403 Forbidden page
    exit();
}

// Database connection settings
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all messages from the messages table
$sql = "SELECT user_id, name, phone_number, email, description, created_at
        FROM messages
        ORDER BY created_at DESC";  // Order messages by the creation time, descending
$result = $conn->query($sql);

// Check for form submission to delete a message
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_message'])) {
    $message_id = $_POST['message_id'];
    $delete_sql = "DELETE FROM messages WHERE user_id = ?";  // Assuming user_id is the unique identifier for message
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param('i', $message_id);
    $stmt->execute();
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Messages</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #003366;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 30px;
            box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar h3 {
            color: #fff;
            text-align: center;
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 12px 20px;
            text-decoration: none;
            border-bottom: 1px solid #ccc;
        }

        .sidebar a:hover {
            background-color: #00509E;
        }

        .main-content {
            margin-left: 270px; /* Space for the sidebar */
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .form-button {
            padding: 5px 10px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-button:hover {
            background-color: #002244;
        }

        h2 {
            color: #333;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
     <div class="sidebar">
   <h3>Employee Dashboard</h3>
    <a href="dashboarde.php" class="active">Dashboard</a>
    <a href="createuser.php">Create User</a>
    <a href="manageusers.php">Manage Users</a>
    <a href="managemessage.php">Manage Messages</a>
   <a href="manageservice.php">Manage Service Request</a>    
<a href="logout.php">Logout</a>
</div>

    <!-- Main Content -->
    <div class="main-content">
        <h2>All Messages</h2>

        <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Sender ID</th>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Email</th>
                    <th>Message</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($message = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $message['user_id']; ?></td>
                    <td><?php echo htmlspecialchars($message['name']); ?></td>
                    <td><?php echo htmlspecialchars($message['phone_number']); ?></td>
                    <td><?php echo htmlspecialchars($message['email']); ?></td>
                    <td><?php echo $message['description']; ?></td>
                    <td><?php echo $message['created_at']; ?></td>
                    <td class="action-buttons">
                        <form method="POST" style="display: inline-block;">
                            <input type="hidden" name="message_id" value="<?php echo $message['user_id']; ?>">
                            <button type="submit" name="delete_message" class="form-button">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No messages found.</p>
        <?php endif; ?>

    </div>

</body>
</html>

<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection settings
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');  // Redirect to login page if not logged in
    exit();
}

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize user variable
$user = null;

// Handle search and update user details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // If account_number is submitted, search for the user
    if (isset($_POST['account_number'])) {
        $account_number = $_POST['account_number'];
        $sql = "SELECT id, username, email, account_number, balance, role, isactive, created_at 
                FROM users WHERE account_number = '$account_number'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
        } else {
            $error_message = "No user found with the provided account number.";
        }
    }

    // If update details form is submitted
    if (isset($_POST['update_user'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        $isactive = isset($_POST['isactive']) ? 1 : 0;  // Active/Inactive

        // Update user details
        $sql = "UPDATE users SET username='$username', email='$email', role='$role', isactive=$isactive 
                WHERE account_number = '$account_number'";
        if ($conn->query($sql) === TRUE) {
            $success_message = "User details updated successfully!";
        } else {
            $error_message = "Error updating user details: " . $conn->error;
        }
    }

    // If change password form is submitted
    if (isset($_POST['change_password'])) {
        $new_password = $_POST['new_password'];
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);  // Hash the password

        // Update password
        $sql = "UPDATE users SET password='$hashed_password' WHERE account_number = '$account_number'";
        if ($conn->query($sql) === TRUE) {
            $success_message = "Password changed successfully!";
        } else {
            $error_message = "Error changing password: " . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Manage User</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f7fa;
      display: flex;
    }

    .sidebar {
      width: 250px;
      background-color: #003366;
      color: white;
      height: 100vh;
      position: fixed;
      padding-top: 30px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      color: #fff;
      text-align: center;
    }

    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      border-bottom: 1px solid #ccc;
    }

    .sidebar a:hover {
      background-color: #00509E;
    }

    .main-content {
      margin-left: 270px;
      padding: 30px;
      width: calc(100% - 270px);
    }

    .container {
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      padding: 20px;
      max-width: 900px;
      margin: 0 auto;
    }

    h2, h3 {
      margin-bottom: 20px;
      font-size: 24px;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    table, th, td {
      border: 1px solid #ddd;
    }

    th, td {
      padding: 12px;
      text-align: left;
    }

    th {
      background-color: #f7f7f7;
    }

    label {
      font-size: 14px;
      margin-bottom: 8px;
      display: block;
      font-weight: bold;
    }

    input, select {
      width: 100%;
      padding: 12px;
      margin: 8px 0;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
    }

    input[type="checkbox"] {
      width: auto;
    }

    button {
      background-color: #003366;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #00509E;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .success-message {
      color: green;
      font-size: 16px;
    }

    .error-message {
      color: red;
      font-size: 16px;
    }

  </style>
</head>
<body>

  <!-- Sidebar -->
     <div class="sidebar">
       <h3>Admin Dashboard</h3>
    <a href="dashboarda.php" class="active">Dashboard</a>
<a href="enum.php">Account management</a>
<a href="manageuseradmin.php"> User Management</a>    
<a href="tools.php">System Tools</a>
    <a href="logout.php">Logout</a>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="container">
      <!-- Input form to enter account_number -->
      <h2>Search User by Account Number</h2>
      <form method="POST">
        <div class="form-group">
          <label for="account_number">Account Number:</label>
          <input type="text" name="account_number" id="account_number" required placeholder="Enter Account Number">
        </div>
        <button type="submit">Search</button>
      </form>

      <?php if (isset($user)): ?>
        <h3>User Details</h3>
        <table>
          <tr>
            <th>Username</th>
            <td><?php echo htmlspecialchars($user['username']); ?></td>
          </tr>
          <tr>
            <th>Email</th>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
          </tr>
          <tr>
            <th>Account Number</th>
            <td><?php echo htmlspecialchars($user['account_number']); ?></td>
          </tr>
          <tr>
            <th>Balance</th>
            <td>₹<?php echo number_format($user['balance'], 2); ?></td>
          </tr>
          <tr>
            <th>Role</th>
            <td><?php echo ucfirst(htmlspecialchars($user['role'])); ?></td>
          </tr>
          <tr>
            <th>Status</th>
            <td><?php echo $user['isactive'] ? 'Active' : 'Inactive'; ?></td>
          </tr>
          <tr>
            <th>Account Created</th>
            <td><?php echo $user['created_at']; ?></td>
          </tr>
        </table>

        <!-- Form to Update User Details -->
        <h3>Update User Details</h3>
        <form method="POST">
          <input type="hidden" name="account_number" value="<?php echo $user['account_number']; ?>">

          <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
          </div>

          <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
          </div>

          <div class="form-group">
            <label for="role">Role:</label>
            <select name="role">
              <option value="user" <?php echo ($user['role'] == 'user') ? 'selected' : ''; ?>>User</option>
              <option value="admin" <?php echo ($user['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
            </select>
          </div>

          <div class="form-group">
            <label for="isactive">Status (Active/Inactive):</label>
            <input type="checkbox" name="isactive" <?php echo $user['isactive'] ? 'checked' : ''; ?>> Active
          </div>

          <button type="submit" name="update_user">Update User</button>
        </form>

        <!-- Form to Change Password -->
        <h3>Change Password</h3>
        <form method="POST">
          <div class="form-group">
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" required placeholder="Enter New Password">
          </div>

          <button type="submit" name="change_password">Change Password</button>
        </form>

        <!-- Success or Error Messages -->
        <?php if (isset($success_message)): ?>
          <p class="success-message"><?php echo $success_message; ?></p>
        <?php elseif (isset($error_message)): ?>
          <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>

      <?php elseif (isset($error_message)): ?>
        <p class="error-message"><?php echo $error_message; ?></p>
      <?php endif; ?>

      <br>
    </div>
  </div>

</body>
</html>

<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

// PHP Server-side code (index.php)
session_start();
// Database connection settings
$host = 'db';      // MySQL host (usually localhost)
$dbname = 'webserver';    // Database name
$dbusername = 'wp_user';  // The MySQL username
$dbpassword = 'your_password';  // The password for the MySQL user

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Log incoming data for debugging
error_log('Received POST data: ' . print_r($_POST, true));
error_log('Encryption Key: ' . $_SERVER['HTTP_X_ENCRYPTION_KEY']);

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the encryption key from the HTTP header (Base64 encoded)
   $encryptionKey = isset($_SERVER['HTTP_X_ENCRYPTION_KEY']) ? base64_decode($_SERVER['HTTP_X_ENCRYPTION_KEY']) : '';
	// Get the encrypted data and IV from POST
    $encryptedData = isset($_POST['data']) ? $_POST['data'] : '';
    $iv = isset($_POST['iv']) ? base64_decode($_POST['iv']) : ''; // The IV is Base64 encoded

    // Log the raw encrypted data and IV
    error_log('Encrypted Data (base64): ' . $encryptedData);
    error_log('IV (base64): ' . base64_encode($iv));

    // Decrypt the data using AES-256-CBC
    if ($encryptedData && $iv) {
        $decryptedData = openssl_decrypt(base64_decode($encryptedData), 'aes-256-cbc', $encryptionKey, OPENSSL_RAW_DATA, $iv);

        // Log the decrypted data
        error_log('Decrypted Data: ' . $decryptedData);

        // Decode the JSON data
        $data = json_decode($decryptedData, true);

        if ($data && isset($data['username']) && isset($data['password'])) {
            $username = $data['username'];
            $password = $data['password'];
	   $logintype = $data['logintype'];

            if ($logintype == 4) {
                // If logintype is 4, show a message about registration in progress
                $error_message = "Registration in progress. Please try again later.";
                echo json_encode(['status' => 'error', 'message' => $error_message]);
                exit();
            }

	// SQL query to get the user from the database
            $sql = "SELECT * FROM users WHERE username = ? and isactive ='1'";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('s', $username); // Bind the username as a string
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                // User found, now check the password directly (plain text comparison)
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    // Login successful, return JSON response
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
		 if ($_SESSION['role'] === 'admin') {
                        echo json_encode(['status' => 'success', 'redirect_url' => 'dashboarda.php']);
                    } elseif ($_SESSION['role'] === 'employee') {
                        echo json_encode(['status' => 'success', 'redirect_url' => 'dashboarde.php']);
                    } else {
                       echo json_encode(['status' => 'success', 'redirect_url' => 'dashboard.php']);
                }    
		exit();
                } else {
                    // Incorrect password
                    $error_message = "Invalid username or password.";
                }
            } else {
                // User not found
                $error_message = "Invalid username or account not active. Please contact administrator.";
            }

            // Close the prepared statement
            $stmt->close();
        } else {
            $error_message = "Decryption failed or invalid data format.";
        }
    } else {
        $error_message = "Missing encrypted data or IV.";
    }

    // Send error message in case of failure
    echo json_encode(['status' => 'error', 'message' => $error_message]);
    exit();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <script src="./crypto-js.js.js"></script>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #f7f7f7;
    }

    .container {
      display: flex;
      width: 70%;
      height: 80%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    .image-side {
      width: 50%;
      background-image: url('./login.jpg'); /* Replace with your image URL */
      background-size: cover;
      background-position: center;
      border-top-left-radius: 8px;
      border-bottom-left-radius: 8px;
    }

    .login-side {
      width: 50%;
      padding: 30px;
      background-color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      border-top-right-radius: 8px;
      border-bottom-right-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    button {
      width: 100%;
      padding: 10px;
      background-color: #003366; /* Dark blue color */
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    button:hover {
      background-color: #002244; /* Darker blue shade for hover effect */
    }

    .forgot-password {
      margin-top: 10px;
      font-size: 14px;
      color: #007BFF;
      text-decoration: none;
    }

    .forgot-password:hover {
      text-decoration: underline;
    }

    /* Error message style */
    .error-message {
      color: red;
      font-size: 14px;
      margin-top: 15px;
    }
  </style>
</head>
<body>

  <div class="container">
    <!-- Image side -->
    <div class="image-side"></div>

    <!-- Login form side -->
    <div class="login-side">
      <h2>Login</h2>

      <!-- Display error message if credentials are wrong -->
      <?php if ($error_message): ?>
        <div class="error-message"><?php echo $error_message; ?></div>
      <?php endif; ?>

      <!-- Login Form -->
	<form id="loginForm">
                <div class="input-group">
                    <input type="text" id="username" placeholder="Username" required>
                </div>
                <div class="input-group">
                    <input type="password" id="password" placeholder="Password" required>
                </div>
                <button type="submit" id="loginButton">Login</button>
                <div id="loadingMessage" style="display:none;">Logging in...</div>
                <div id="errorMessage" style="display:none; color: red;"></div>
            </form>


      <a href="reset-request.php" class="forgot-password">Forgot Password?</a>
    </div>
  </div>


    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent form from submitting normally

            // Get form data
            var formData = {
                username: document.getElementById('username').value,
                password: document.getElementById('password').value,
            	logintype: 4 // Hidden logintype that is set to '4' for registration process
		};

            // Show loading message
            document.getElementById('loadingMessage').style.display = 'block';
            document.getElementById('errorMessage').style.display = 'none';

            // Ensure the inputs are not empty
            if (!formData.username || !formData.password) {
                document.getElementById('errorMessage').style.display = 'block';
                document.getElementById('errorMessage').innerText = 'Username and Password cannot be empty';
                document.getElementById('loadingMessage').style.display = 'none';
                return;
            }

            // Fixed 32-character secret key (256 bits)
           // Generate a random 32-byte (256-bit) encryption key
             var encryptionKey = CryptoJS.lib.WordArray.random(32); // 32 bytes = 256 bits

             // Convert the encryption key to a Base64 string
             var encryptionKeyBase64 = encryptionKey.toString(CryptoJS.enc.Base64);

             // Log the Base64 encoded key for debugging
            //var encryptionKey = CryptoJS.enc.Utf8.parse('thisisaverysecretkeywith32chars!'); // 32 characters (256 bits)

            // Fixed 16-byte IV with 16 zeros
            var iv = CryptoJS.enc.Utf8.parse('0000000000000000'); // 16 bytes (128 bits)

            // Encrypt the form data using AES with the secret key and fixed IV
            var encryptedData = CryptoJS.AES.encrypt(JSON.stringify(formData), encryptionKey, { iv: iv }).toString();

            // Log the encrypted data and IV for debugging purposes

            // Create a FormData object with encrypted data and IV
            var sendData = new FormData();
            sendData.append('data', encryptedData); // The encrypted data
            sendData.append('iv', CryptoJS.enc.Base64.stringify(iv));  // The IV (Initialization Vector)

            // Send the data via AJAX
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'index.php', true);
            xhr.setRequestHeader('X-Encryption-Key', CryptoJS.enc.Base64.stringify(encryptionKey)); // Send the encryption key in Base64 format

            xhr.onload = function() {
                if (xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        window.location.href = response.redirect_url; // Redirect on success
                    } else {
                        document.getElementById('errorMessage').style.display = 'block';
                        document.getElementById('errorMessage').innerText = response.message;
                    }
                } else {
                    document.getElementById('errorMessage').style.display = 'block';
                    document.getElementById('errorMessage').innerText = 'Server error. Try again later.';
                }
                document.getElementById('loadingMessage').style.display = 'none';
            };

            xhr.onerror = function() {
                document.getElementById('loadingMessage').style.display = 'none';
                document.getElementById('errorMessage').style.display = 'block';
                document.getElementById('errorMessage').innerText = 'Network error, request failed';
            };

            xhr.send(sendData);
        });
    </script>
</body>
</html>

<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Step 1: Generate a random token (e.g., using a secure random generator)
$token = bin2hex(random_bytes(16));  // Generate a 32-character hexadecimal token

// Step 2: Use the token to generate a reset password URL
$reset_url = "http://" . $_SERVER['HTTP_HOST'] . "/reset-password?token=$token";

//$reset_url = "http://$_SERVER['HTTP_HOST']/reset-password?token=$token";

// Step 3: Display the token and URL on the screen
echo "Your password reset token is: $token <br>";
echo "Click here to reset your password: <a href='$reset_url'>$reset_url</a>";

// Optional: Send the reset URL via email (this is more realistic, but not strictly necessary)
//$email = 'user@example.com'; // Example email address (you'd typically get this from user input)
//mail($email, "Password Reset", "Click here to reset your password: $reset_url");

?>

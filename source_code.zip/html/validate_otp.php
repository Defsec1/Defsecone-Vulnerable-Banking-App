<?php
// Start the session
session_start();

// Check if OTP session variable is set
if (!isset($_SESSION['otp_sent'])) {
    header("Location: forgot_password.php");  // Redirect to forgot password page if OTP not sent
    exit();
}

$otpError = '';
$otpSuccess = '';

// Check if the logged-in user is an admin or employee
// Assuming role is stored in the session for logged-in users
$isAdminOrEmployee = isset($_SESSION['role']) && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'employee');

// Handle OTP validation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['otp'])) {
    $inputOtp = $_POST['otp'];

    // Check if the OTP entered matches the session OTP
    if ($_SESSION['otp'] == $inputOtp) {
        // OTP is valid, redirect to password change page
        header("Location: new_password.php");
        exit(); // Redirect to password change page
    } else {
        $otpError = "Invalid OTP. Please try again.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validate OTP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }

        .container {
            width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        .error {
            color: red;
            font-weight: bold;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        form input {
            padding: 10px;
            font-size: 16px;
            width: 100%;
            margin: 10px 0;
        }

        form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        form button:hover {
            background-color: #0056b3;
        }

        .otp-display {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Validate OTP</h2>

    <!-- Display error message if OTP is invalid -->
    <?php if ($otpError): ?>
        <div class="error"><?php echo $otpError; ?></div>
    <?php endif; ?>

    <!-- For admin and employee users, do not display OTP -->
    <?php if (!$isAdminOrEmployee): ?>
        <div class="otp-display">
            <p>Your OTP is: <strong><?php echo $_SESSION['otp']; ?></strong></p>
        </div>
    <?php else: ?>
        <p>Your OTP has been sent securely, please enter the OTP to proceed.</p>
    <?php endif; ?>

    <!-- OTP Form -->
    <form method="POST" action="">
        <label for="otp">Enter the OTP:</label>
        <input type="text" id="otp" name="otp" required>

        <button type="submit">Validate OTP</button>
    </form>
</div>

</body>
</html>

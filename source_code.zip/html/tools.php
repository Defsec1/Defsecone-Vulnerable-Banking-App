<?php
// Initialize variables for ping, traceroute, and logs
$pingResult = '';
$tracerouteResult = '';
$logResult = '';
$errorMessage = '';
// Start the session
session_start();

// Enable error reporting for debugging
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

// Check if the user is logged in and is an employee or admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');  // Redirect to login page if not logged in
    exit();
}

// Get current system time
$currentTime = date('Y-m-d H:i:s');  // Format: YYYY-MM-DD HH:MM:SS

// Check if the form was submitted and the 'ip' field is present
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['ip'])) {
        // Get the IP address from the POST request
        $ip = $_POST['ip'];

        // Validate the IP address to ensure it's a valid IPv4 address
        //if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {

            // Ping Command
            if (isset($_POST['ping'])) {
                // Execute the ping command (Linux/Unix system)
                if (strncasecmp(PHP_OS, 'win', 3) === 0) {
                    // Windows-specific ping command
                    $pingResult = shell_exec("ping -n 4 $ip");
                } else {
                    // Linux/Unix-specific ping command
                    $pingResult = shell_exec("ping -c 4 $ip");
                }
            }

            // Traceroute Command
            if (isset($_POST['traceroute'])) {
                // Execute the traceroute command (Linux/Unix system)
                if (strncasecmp(PHP_OS, 'win', 3) === 0) {
                    // Windows-specific traceroute command
                    $tracerouteResult = shell_exec("tracert $ip");
                } else {
                    // Linux/Unix-specific traceroute command
                    $tracerouteResult = shell_exec("traceroute $ip");
                }
            }
        } else {
            $errorMessage = "Error: Invalid IP Address.";
        }
   // }
    
    // Log Viewing
    if (isset($_POST['view_logs'])) {
        // Check if the user has permission to read the log file
        $logFilePath = '/etc/apache2/apache2.conf';

        // Check if the file exists
        if (file_exists($logFilePath)) {
            // Attempt to read the log file content
            $logResult = file_get_contents($logFilePath);
            if ($logResult === false) {
                $logResult = "Error: Unable to read the log file.";
            }
        } else {
            $logResult = "Error: Log file does not exist.";
        }
    }
}

// Check if the form is submitted and the 'url' field is set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
    $url = $_POST['url'];  // Capture the URL from the form input

    // Validate the URL to ensure it has a proper format
    if (filter_var($url, FILTER_VALIDATE_URL)) {
        // Attempt to fetch content from the provided URL (SSRF Vulnerability)
        $response = @file_get_contents($url);  // Suppress errors to prevent info leakage

        // Check if the content was fetched successfully
        if ($response !== false) {
            $ssrf= htmlspecialchars($response);
        } else {
            echo "Failed to fetch content from the URL.";
        }
    } else {
        echo "Invalid URL!";
    }
} else {
    echo "";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      margin: 0;
      display: flex;
    }

    /* Sidebar */
    .sidebar {
      width: 250px;
      background-color: #003366;
      color: white;
      height: 100vh;
      position: fixed;
      padding-top: 30px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      color: #fff;
      text-align: center;
    }

    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      border-bottom: 1px solid #ccc;
    }

    .sidebar a:hover {
      background-color: #00509E;
    }

    .sidebar a.active {
      background-color: #00509E;
    }

    /* Main Content */
    .main-content {
      margin-left: 270px;
      padding: 20px;
      width: calc(100% - 270px);
    }

    .container {
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    /* Result Container */
    .result-container {
      margin-top: 30px;
    }

    /* Form Styling */
    form {
      margin-bottom: 20px;
    }

    form input {
      padding: 8px;
      font-size: 16px;
      width: 250px;
      margin-right: 10px;
    }

    form button {
      padding: 8px 16px;
      font-size: 16px;
      background-color: #007bff;
      color: white;
      border: none;
      cursor: pointer;
    }

    form button:hover {
      background-color: #0056b3;
    }

    /* Preformatted Output Styling */
    pre {
      background-color: #f1f1f1;
      padding: 10px;
      border-radius: 4px;
      border: 1px solid #ccc;
      font-size: 14px;
      white-space: pre-wrap;
      word-wrap: break-word;
    }

    /* System Time Section */
    .system-time {
      margin-top: 30px;
      font-size: 18px;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
     <div class="sidebar">
       <h3>Admin Dashboard</h3>
    <a href="dashboarda.php" class="active">Dashboard</a>
<a href="enum.php">Account management</a>
<a href="manageuseradmin.php"> User Management</a>    
<a href="tools.php">System Tools</a>
    <a href="logout.php">Logout</a>
  </div>

  <!-- Main content -->
  <div class="main-content">
    <div class="container">
      
      <!-- System Time Feature -->
      <div class="system-time">
        <h3>Current System Time</h3>
        <p><?php echo "The current server time is: " . $currentTime; ?></p>
      </div>

      <!-- Ping and Traceroute Feature -->
      <h2>Network Diagnostics</h2>

      <!-- Ping Form -->
      <div class="result-container">
        <h3>Ping an IP Address</h3>
        <form action="tools.php" method="POST">
          <label for="ip">Enter IP Address:</label>
          <input type="text" id="ip" name="ip" required>
          <button type="submit" name="ping">Ping</button>
        </form>

        <?php if ($pingResult): ?>
          <h4>Ping Result for <?php echo htmlspecialchars($ip); ?>:</h4>
          <pre><?php echo htmlspecialchars($pingResult); ?></pre>
        <?php elseif ($errorMessage && isset($_POST['ping'])): ?>
          <h3><?php echo $errorMessage; ?></h3>
        <?php endif; ?>
      </div>

      <!-- Traceroute Form -->
      <div class="result-container">
        <h3>Traceroute to an IP Address</h3>
        <form action="tools.php" method="POST">
          <label for="ip">Enter IP Address:</label>
          <input type="text" id="ip" name="ip" required>
          <button type="submit" name="traceroute">Traceroute</button>
        </form>

        <?php if ($tracerouteResult): ?>
          <h4>Traceroute Result for <?php echo htmlspecialchars($ip); ?>:</h4>
          <pre><?php echo htmlspecialchars($tracerouteResult); ?></pre>
        <?php elseif ($errorMessage && isset($_POST['traceroute'])): ?>
          <h3><?php echo $errorMessage; ?></h3>
        <?php endif; ?>
      </div>
       <div class="result-container">
	<h3>Internal Communication Request</h3>
	<form action="" method="POST">
        <label for="url">Enter URL:</label>
        <input type="text" id="url" name="url" placeholder="http://example.com" required>
        <button type="submit" value="Fetch URL">Fetch</button>
    </form>
	<?php if($ssrf): ?>
	<h4> Internal communication results:</h4>
	<pre><?php echo htmlspecialchars($ssrf); ?></pre>
	<?php endif; ?>
	</div>

	<!----Fixing--code-->
	
      <!-- View Logs Form -->
      <div class="result-container">
        <h3>View Apache Configuration File</h3>
        <form action="tools.php" method="POST">
          <button type="submit" name="view_logs">View Logs</button>
        </form>

        <?php if ($logResult): ?>
          <h4>Apache Configuration:</h4>
          <pre><?php echo htmlspecialchars($logResult); ?></pre>
        <?php elseif ($logResult === false): ?>
          <h3>Error reading log file.</h3>
        <?php endif; ?>
      </div>
	<!-- View source Files -->
      <div class="result-container">
        <h3>View Apache Source code (Under Development)</h3>
        <form action="tools.php" method="GET">
	<input type="text" id="file" name="file" required>
        <button type="submit" name="submit">View File</button>
</form>
<?php include '/var/www/html' . $_GET['file']; ?>
    </div>
</body>
</html>

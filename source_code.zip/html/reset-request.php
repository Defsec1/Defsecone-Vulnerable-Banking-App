<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection details (adjust according to your environment)
$host = 'db';
$dbname = 'webserver';  // Replace with your actual database name
$username = 'wp_user';         // Replace with your database username
$password = 'your_password';             // Replace with your database password

// Establish a PDO connection to the database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Step 1: Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['method'])) {
        $method = $_POST['method'];

        if ($method == 'reset_link') {
            // Handle the reset via reset link (Email)
            $email = trim($_POST['email']);
            $sql = "SELECT * FROM users WHERE email = :email";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                echo "No account found with that email address.";
                exit;
            }

            // Check the user's role
            if ($user['role'] !== 'standard') {
                echo "Password reset is only available for standard users.";
                exit;
            }

            // Generate a secure, random token
            $token = bin2hex(random_bytes(16));  // Generate a 32-character hexadecimal token

            // Set the token expiration time (1 hour from now)
            $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Insert the token and expiration time into the password_resets table
            $sql = "INSERT INTO password_resets (email, token, expires_at) VALUES (:email, :token, :expires_at)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':email' => $email,
                ':token' => $token,
                ':expires_at' => $expires_at,
            ]);

            // Generate the reset password URL
            $reset_url = "http://" . $_SERVER['HTTP_HOST'] . "/reset-password.php?token=$token";

            // Show the reset link
           // echo "Your password reset token is: <strong>$token</strong><br>";
           // echo "Click here to reset your password: <a href='$reset_url'>$reset_url</a><br>";
        } elseif ($method == 'otp') {
            // Redirect to OTP request page
            header('Location: forgot_password.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 50px;
        }
        h2 {
            text-align: center;
            color: #007BFF;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        label {
            font-weight: bold;
            font-size: 1rem;
        }
        input[type="email"] {
            padding: 10px;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
        }
        button {
            padding: 12px 20px;
            background-color: #007BFF;
            color: #fff;
            font-size: 1rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            margin-top: 20px;
            color: #ff0000;
        }
        .info {
            text-align: center;
            margin-top: 20px;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Password Reset</h2>
    <form action="reset-request.php" method="POST">
        <label for="method">Choose your preferred reset method:</label>
        <div>
            <label for="reset_link">
                <input type="radio" id="reset_link" name="method" value="reset_link" required> Reset via Reset Link (Email)
            </label>
            <label for="otp">
                <input type="radio" id="otp" name="method" value="otp"> Reset via OTP (One-Time Password)
            </label>
        </div>
        
        <!-- If Reset via Reset Link is selected, show the email input field -->
        <div id="emailField" style="display: none;">
            <label for="email">Enter your email address:</label>
            <input type="email" id="email" name="email">
        </div>

        <button type="submit">Continue</button>
    </form>
<?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($reset_url)): ?>
        <div class="info">
            <p>Your password reset token is: <strong><?php echo $token; ?></strong></p>
            <p>Click here to reset your password: <a href="<?php echo $reset_url; ?>"><?php echo $reset_url; ?></a></p>
        </div>
    <?php endif; ?>
</div>

<script>
    // Show email input field when "Reset via Reset Link" is selected
    const resetLinkOption = document.getElementById('reset_link');
    const otpOption = document.getElementById('otp');
    const emailField = document.getElementById('emailField');

    resetLinkOption.addEventListener('change', () => {
        emailField.style.display = 'block';
    });

    otpOption.addEventListener('change', () => {
        emailField.style.display = 'none';
    });
</script>

</body>
</html>

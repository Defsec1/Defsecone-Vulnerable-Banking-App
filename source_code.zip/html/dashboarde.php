<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in and is an employee or admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'employee' && $_SESSION['role'] != 'admin')) {
    header('Location: login.php');  // Redirect to login page if not logged in
    exit();
}

// Database connection settings
$host = 'localhost';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to hold the counts
$total_users = 0;
$active_users = 0;
$inactive_users = 0;
$total_admins = 0;
$total_messages = 0;
$service_requests_in_progress = 0;

// Get total number of users
$sql = "SELECT COUNT(*) FROM users";
$result = $conn->query($sql);
$total_users = $result->fetch_row()[0];

// Get number of active users
$sql_active = "SELECT COUNT(*) FROM users WHERE isactive = 1";
$result_active = $conn->query($sql_active);
$active_users = $result_active->fetch_row()[0];

// Get number of inactive users
$sql_inactive = "SELECT COUNT(*) FROM users WHERE isactive = 0";
$result_inactive = $conn->query($sql_inactive);
$inactive_users = $result_inactive->fetch_row()[0];

// Get number of admin accounts
$sql_admin = "SELECT COUNT(*) FROM users WHERE role = 'admin'";
$result_admin = $conn->query($sql_admin);
$total_admins = $result_admin->fetch_row()[0];

// Get number of messages received (assuming `messages` table exists)
$sql_messages = "SELECT COUNT(*) FROM messages";
$result_messages = $conn->query($sql_messages);
$total_messages = $result_messages->fetch_row()[0];

// Get number of service requests in progress (assuming `service_requests` table exists with `status` column)
$sql_service_requests = "SELECT COUNT(*) FROM service_requests WHERE status = 'in progress'";
$result_service_requests = $conn->query($sql_service_requests);
$service_requests_in_progress = $result_service_requests->fetch_row()[0];

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      margin: 0;
      display: flex;
    }

    /* Sidebar */
    .sidebar {
      width: 250px;
      background-color: #003366;
      color: white;
      height: 100vh;
      position: fixed;
      padding-top: 30px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      color: #fff;
      text-align: center;
    }

    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      border-bottom: 1px solid #ccc;
    }

    .sidebar a:hover {
      background-color: #00509E;
    }

    .sidebar a.active {
      background-color: #00509E;
    }

    /* Main Content */
    .main-content {
      margin-left: 270px;
      padding: 20px;
      width: calc(100% - 270px);
    }

    .container {
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    .dashboard-cards {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
    }

    .dashboard-card {
      background-color: #fff;
      padding: 20px;
      margin: 10px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      width: 30%;
      text-align: center;
    }

    .dashboard-card h3 {
      margin-bottom: 20px;
      font-size: 24px;
    }

    .dashboard-card p {
      font-size: 18px;
      color: #555;
    }

    .dashboard-card.active {
      background-color: #28a745;
      color: white;
    }

    .dashboard-card.inactive {
      background-color: #dc3545;
      color: white;
    }

    .dashboard-card.admin {
      background-color: #007bff;
      color: white;
    }

    .dashboard-card.messages {
      background-color: #17a2b8;
      color: white;
    }

    .dashboard-card.requests {
      background-color: #ffc107;
      color: white;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
   <div class="sidebar">
   <h3>Employee Dashboard</h3>
    <a href="dashboarde.php" class="active">Dashboard</a>
    <a href="createuser.php">Create User</a>
    <a href="manageusers.php">Manage Users</a>
    <a href="managemessage.php">Manage Messages</a>
   <a href="manageservice.php">Manage Service Request</a>    
<a href="logout.php">Logout</a>
  </div>

  <!-- Main content -->
  <div class="main-content">
    <div class="container">
      <h2>Admin Dashboard</h2>
      
      <!-- Dashboard Cards -->
      <div class="dashboard-cards">

        <!-- Total Users -->
        <div class="dashboard-card">
          <h3>Total Users</h3>
          <p><?php echo $total_users; ?></p>
        </div>

        <!-- Active Users -->
        <div class="dashboard-card active">
          <h3>Active Users</h3>
          <p><?php echo $active_users; ?></p>
        </div>

        <!-- Inactive Users -->
        <div class="dashboard-card inactive">
          <h3>Inactive Users</h3>
          <p><?php echo $inactive_users; ?></p>
        </div>

        <!-- Admin Accounts -->
        <div class="dashboard-card admin">
          <h3>Total Admin Accounts</h3>
          <p><?php echo $total_admins; ?></p>
        </div>

        <!-- Messages Received -->
        <div class="dashboard-card messages">
          <h3>Messages Received</h3>
          <p><?php echo $total_messages; ?></p>
        </div>

        <!-- Service Requests In Progress -->
        <div class="dashboard-card requests">
          <h3>Service Requests In Progress</h3>
          <p><?php echo $service_requests_in_progress; ?></p>
        </div>

      </div>
    </div>
  </div>

</body>
</html>

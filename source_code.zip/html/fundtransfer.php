<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');  // Redirect to login page if not logged in
    exit();
}

// Database connection settings
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user data based on session
$user_id = $_SESSION['user_id'];
$sql = "SELECT id, username, email, account_number, balance FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if user exists
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    die("User not found.");
}

$error_message = '';
$success_message = '';

// Handle the fund transfer form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $destination_account = $_POST['destination_account'];
    $transfer_amount = $_POST['transfer_amount'];

    // Validate input
    if (empty($destination_account) || empty($transfer_amount)) {
        $error_message = 'Please provide both destination account and transfer amount.';
    } elseif (!is_numeric($transfer_amount) || $transfer_amount <= 0) {
        $error_message = 'Please enter a valid transfer amount.';
    } elseif ($transfer_amount > $user['balance']) {
        $error_message = 'Insufficient balance for the transfer.';
    } else {
        // Check if the destination account exists
        $sql_check_dest = "SELECT id, balance FROM users WHERE account_number = ?";
        $stmt_check_dest = $conn->prepare($sql_check_dest);
        $stmt_check_dest->bind_param('s', $destination_account);
        $stmt_check_dest->execute();
        $result_dest = $stmt_check_dest->get_result();

        if ($result_dest->num_rows > 0) {
            $destination_user = $result_dest->fetch_assoc();

            // Start a transaction
            $conn->begin_transaction();

            try {
                // Deduct balance from source account
                $new_source_balance = $user['balance'] - $transfer_amount;
                $sql_update_source = "UPDATE users SET balance = ? WHERE id = ?";
                $stmt_update_source = $conn->prepare($sql_update_source);
                $stmt_update_source->bind_param('di', $new_source_balance, $user['id']);
                $stmt_update_source->execute();

                // Add balance to destination account
                $new_dest_balance = $destination_user['balance'] + $transfer_amount;
                $sql_update_dest = "UPDATE users SET balance = ? WHERE account_number = ?";
                $stmt_update_dest = $conn->prepare($sql_update_dest);
                $stmt_update_dest->bind_param('ds', $new_dest_balance, $destination_account);
                $stmt_update_dest->execute();

                // Log the transaction for source account (Debit)
                $sql_insert_source = "INSERT INTO transactions (user_id, transaction_type, amount, balance_after, destination_account) 
                                      VALUES (?, 'debit', ?, ?, ?)";
                $stmt_insert_source = $conn->prepare($sql_insert_source);
                $stmt_insert_source->bind_param('idds', $user['id'], $transfer_amount, $new_source_balance, $destination_account);
                $stmt_insert_source->execute();

                // Log the transaction for destination account (Credit)
                $sql_insert_dest = "INSERT INTO transactions (user_id, transaction_type, amount, balance_after, destination_account) 
                                    VALUES (?, 'credit', ?, ?, ?)";
                $stmt_insert_dest = $conn->prepare($sql_insert_dest);
                $stmt_insert_dest->bind_param('idds', $destination_user['id'], $transfer_amount, $new_dest_balance, $user['account_number']);
                $stmt_insert_dest->execute();

                // Commit transaction
                $conn->commit();

                // Success message
                $success_message = 'Transfer successful!';

                // Update the session user's balance
                $user['balance'] = $new_source_balance;

            } catch (Exception $e) {
                // Rollback transaction in case of an error
                $conn->rollback();
                $error_message = 'Error occurred during transfer. Please try again.';
            }
        } else {
            $error_message = 'Destination account not found.';
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fund Transfer</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      display: flex;
    }

    /* Sidebar */
    .sidebar {
      width: 250px;
      background-color: #003366;
      color: white;
      height: 100vh;
      position: fixed;
      padding-top: 30px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      color: #fff;
      text-align: center;
    }

    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      border-bottom: 1px solid #ccc;
    }

    .sidebar a:hover {
      background-color: #00509E;
    }

    .main-content {
      margin-left: 270px;
      padding: 20px;
      width: calc(100% - 270px);
    }

    .container {
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    table, th, td {
      border: 1px solid #ddd;
    }

    th, td {
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #f2f2f2;
    }

    .error-message {
      color: red;
    }

    .success-message {
      color: green;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    button {
      padding: 10px 20px;
      background-color: #003366;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:hover {
      background-color: #002244;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h3>Dashboard</h3>
    <a href="dashboard.php">Home</a>
    <a href="fundtransfer.php">Fund Transfer</a>
    <a href="fixeddeposit.php">Fixed Deposit</a>
    <a href="applydebitcard.php">Apply Debit Card</a>
    <a href="applycreditcard.php">Apply Credit Card</a>
    <a href="checkbalance.php">Check Balance</a>
    <a href="accountstatement.php">Account Statement</a>
    <a href="blockcard.php">Block Card</a>
    <a href="servicerequest.php">Service Request</a>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="container">
      <h2>Fund Transfer</h2>

      <!-- Error or Success message -->
      <?php if ($error_message): ?>
        <div class="error-message"><?php echo $error_message; ?></div>
      <?php elseif ($success_message): ?>
        <div class="success-message"><?php echo $success_message; ?></div>
      <?php endif; ?>

      <!-- Balance info -->
      <p><strong>Account Balance:</strong> ₹<?php echo number_format($user['balance'], 2); ?></p>

      <!-- Fund Transfer Form -->
      <form method="POST">
        <div class="form-group">
          <input type="text" name="destination_account" placeholder="Destination Account Number" required>
        </div>
        <div class="form-group">
          <input type="number" name="transfer_amount" placeholder="Amount to Transfer" required>
        </div>
        <button type="submit">Transfer</button>
      </form>
    </div>
  </div>

</body>
</html>

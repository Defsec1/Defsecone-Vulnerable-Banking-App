<?php
// Enable error reporting to troubleshoot
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection settings
$host = 'db';      // MySQL host (usually localhost)
$dbname = 'webserver';    // Database name
$dbusername = 'wp_user';  // The MySQL username
$dbpassword = 'your_password';  // The password for the MySQL user

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $logintype = $_POST['logintype'];

    // Validate if all fields are filled
    if ($username && $email && $password && $logintype) {
        // Check if username or email already exists
        $sql = "SELECT * FROM users WHERE username = ? OR email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error_message = 'Username or email already exists.';
        } else {
            // Hash the password before storing it
            $passwordHash = password_hash($password, PASSWORD_BCRYPT);

            // Generate account number based on count of users in database
            $account_number = 202500000 + (int)$conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0];

            // Default balance is 1000.00
            $balance = 1000.00;

            // Set 'isactive' based on role
            // If the role is 'standard', set isactive to 1, else set it to 0
            $isactive = ($logintype === 'standard') ? 1 : 0;

            // Prepare the SQL INSERT query
            $insertSQL = "INSERT INTO users (username, password, email, role, account_number, balance, isactive) 
                          VALUES (?, ?, ?, ?, ?, ?, ?)";

            $insertStmt = $conn->prepare($insertSQL);
            if (!$insertStmt) {
                $error_message = "Error preparing statement: " . $conn->error;
            } else {
                $insertStmt->bind_param('ssssdis', $username, $passwordHash, $email, $logintype, $account_number, $balance, $isactive);

                if ($insertStmt->execute()) {
                    $success_message = 'Registration successful!';
                } else {
                    $error_message = 'Failed to register user: ' . $insertStmt->error;
                }

                // Close the prepared statement
                $insertStmt->close();
            }
        }

        // Close the query statement
        $stmt->close();
    } else {
        $error_message = 'Please fill in all fields.';
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Page</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #f7f7f7;
    }

    .container {
      display: flex;
      width: 70%;
      height: 80%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }

    .image-side {
      width: 50%;
      background-image: url('./login.jpg'); /* Replace with your image URL */
      background-size: cover;
      background-position: center;
      border-top-left-radius: 8px;
      border-bottom-left-radius: 8px;
    }

    .register-side {
      width: 50%;
      padding: 30px;
      background-color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      border-top-right-radius: 8px;
      border-bottom-right-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    input[type="text"],
    input[type="password"],
    input[type="email"],
    select {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    button {
      width: 100%;
      padding: 10px;
      background-color: #003366; /* Dark blue color */
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    button:hover {
      background-color: #002244; /* Darker blue shade for hover effect */
    }

    .forgot-password {
      margin-top: 10px;
      font-size: 14px;
      color: #007BFF;
      text-decoration: none;
    }

    .forgot-password:hover {
      text-decoration: underline;
    }

    /* Error and success message styles */
    .error-message {
      color: red;
      font-size: 14px;
      margin-top: 15px;
    }

    .success-message {
      color: green;
      font-size: 14px;
      margin-top: 15px;
    }
  </style>
</head>
<body>

  <div class="container">
    <!-- Image side -->
    <div class="image-side"></div>

    <!-- Register form side -->
    <div class="register-side">
      <h2>Register</h2>

      <!-- Display error or success message -->
      <?php if ($error_message): ?>
        <div class="error-message"><?php echo $error_message; ?></div>
      <?php elseif ($success_message): ?>
        <div class="success-message"><?php echo $success_message; ?></div>
      <?php endif; ?>

      <!-- Registration Form -->
      <form id="registerForm" method="POST">
        <div class="input-group">
          <input type="text" id="username" name="username" placeholder="Username" required>
        </div>
        <div class="input-group">
          <input type="email" id="email" name="email" placeholder="Email" required>
        </div>
        <div class="input-group">
          <input type="password" id="password" name="password" placeholder="Password" required>
        </div>
        <div class="input-group">
          <select id="logintype" name="logintype" required>
            <option value="" disabled selected>Select Role</option>
            <option value="admin">Admin</option>
            <option value="standard">Standard</option>
            <option value="employee">Employee</option>
          </select>
        </div>
        <button type="submit">Register</button>
      </form>
    </div>
  </div>

</body>
</html>

<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in and is an employee
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'employee') {
    header('Location: login.php');  // Redirect to login page if not logged in
    exit();
}

// Database connection settings
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';

// Create a connection to the database
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$username = $email = $password = $confirm_password = $role = "";
$isactive = 0; // Default is active
$username_err = $email_err = $password_err = $confirm_password_err = $role_err = "";

// Process form data when submitted for user creation
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } else {
        $username = trim($_POST["username"]);
    }

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter an email.";
    } else {
        $email = trim($_POST["email"]);
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm the password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if ($password != $confirm_password) {
            $confirm_password_err = "Password did not match.";
        }
    }

    // Validate role
    if (empty($_POST["role"])) {
        $role_err = "Please select a role.";
    } else {
        $role = $_POST["role"];
    }

    // Check if there are no errors before inserting into the database
    if (empty($username_err) && empty($email_err) && empty($password_err) && empty($confirm_password_err) && empty($role_err)) {
        // Generate account number based on existing users
        $account_number_query = "SELECT COUNT(*) FROM users";
        $result = $conn->query($account_number_query);
        $count = $result->fetch_row()[0];  // Get the current count of users
        $account_number = 202500000 + (int)$count;  // Increment the count for a new account number

        // Default balance
        $balance = 1000.00;

        // Prepare the SQL query to insert the new user
        $sql = "INSERT INTO users (username, email, password, role, isactive, account_number, balance) VALUES (?, ?, ?, ?, ?, ?, ?)";

        if ($stmt = $conn->prepare($sql)) {
            // Bind the variables to the prepared statement
            $stmt->bind_param("ssssisi", $username, $email, $password_hash, $role, $isactive, $account_number, $balance);

            // Hash the password before inserting into the database
            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            // Execute the statement
            if ($stmt->execute()) {
                // Redirect to the user management page (or success page)
                header("Location: dashboarde.php"); // Refresh the page after user creation
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }

    // Close connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      padding: 20px;
    }

    .container {
      background-color: white;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      padding: 20px;
      max-width: 600px;
      margin: 0 auto;
    }

    h2 {
      text-align: center;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      font-size: 16px;
      margin-bottom: 5px;
    }

    input[type="text"], input[type="email"], input[type="password"], select {
      width: 100%;
      padding: 10px;
      border-radius: 4px;
      border: 1px solid #ccc;
    }

    .error {
      color: red;
      font-size: 14px;
    }

    .btn {
      background-color: #003366;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      width: 100%;
    }

    .btn:hover {
      background-color: #002244;
    }

    .checkbox-group input[type="checkbox"] {
      margin-right: 10px;
    }

    /* Sidebar styles */
    .sidebar {
      width: 250px;
      background-color: #003366;
      color: white;
      height: 100vh;
      position: fixed;
      padding-top: 30px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      color: #fff;
      text-align: center;
    }

    .sidebar a {
      display: block;
      color: #fff;
      padding: 12px 20px;
      text-decoration: none;
      border-bottom: 1px solid #ccc;
    }

    .sidebar a:hover {
      background-color: #00509E;
    }

    .main-content {
      margin-left: 270px; /* Space for the sidebar */
      padding: 20px;
      width: calc(100% - 270px);
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
   <h3>Employee Dashboard</h3>
    <a href="dashboarde.php" class="active">Dashboard</a>
    <a href="createuser.php">Create User</a>
    <a href="manageusers.php">Manage Users</a>
    <a href="managemessage.php">Manage Messages</a>
   <a href="manageservice.php">Manage Service Request</a>    
<a href="logout.php">Logout</a>

  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="container">
      <h2>Create New User</h2>
      <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

        <!-- Username -->
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" value="<?php echo $username; ?>">
          <span class="error"><?php echo $username_err; ?></span>
        </div>

        <!-- Email -->
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" value="<?php echo $email; ?>">
          <span class="error"><?php echo $email_err; ?></span>
        </div>

        <!-- Password -->
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" value="<?php echo $password; ?>">
          <span class="error"><?php echo $password_err; ?></span>
        </div>

        <!-- Confirm Password -->
        <div class="form-group">
          <label for="confirm_password">Confirm Password</label>
          <input type="password" id="confirm_password" name="confirm_password" value="<?php echo $confirm_password; ?>">
          <span class="error"><?php echo $confirm_password_err; ?></span>
        </div>

        <!-- Role -->
        <div class="form-group">
          <label for="role">Role</label>
          <select id="role" name="role">
            <option value="user" <?php echo ($role == 'user') ? 'selected' : ''; ?>>User</option>
            <option value="employee" <?php echo ($role == 'employee') ? 'selected' : ''; ?>>Employee</option>
           </select>
          <span class="error"><?php echo $role_err; ?></span>
        </div>

        <!-- Submit Button -->
        <div class="form-group">
          <button type="submit" class="btn">Create User</button>
        </div>

      </form>
    </div>
  </div>

</body>
</html>

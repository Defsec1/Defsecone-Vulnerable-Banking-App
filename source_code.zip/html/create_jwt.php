<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Include the JWT library (make sure the path to the autoload.php is correct)
require_once '/var/www/html/vendor/autoload.php';  // Adjust to your Composer autoload path

use \Firebase\JWT\JWT;

// Database connection details
$host = 'db';
$dbname = 'webserver';   // Your database name
$username = 'wp_user';      // Your database username
$password = 'your_password';          // Your database password

try {
    // Create a PDO connection to the database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Assume user is logging in with a username and password
// For simplicity, let's assume we're hardcoding the username (could be from form input)
$user_input_username = 'admin';

// Query the database to retrieve user details
$sql = "SELECT id, username, role FROM users WHERE username = :username LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->execute([':username' => $user_input_username]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    // User found, now generate a JWT token with user data
    
    // Secret key for signing the token
    $secret_key = "your_secret_key"; // Replace with your actual secret key

    // Get the current time and set an expiration time
    $issuedAt = time();
    $expirationTime = $issuedAt + 3600;  // 1 hour expiration time

    // JWT payload (data to be encoded in the token)
    $payload = array(
        "iat" => $issuedAt,       // Issued at: current time
        "exp" => $expirationTime, // Expiration time
        "sub" => $user['id'],     // Subject: user ID
        "username" => $user['username'], // Username from DB
        "role" => $user['role']   // User role from DB
    );

    // Encode the payload into a JWT token
    $jwt = JWT::encode($payload, $secret_key, 'HS256');  // Using HS256 algorithm

    // Output the JWT token
    echo "Generated JWT: " . $jwt;
} else {
    echo "User not found!";
}
?>

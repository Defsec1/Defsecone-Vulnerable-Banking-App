-- Table for Users
CREATE TABLE `users` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(255) NOT NULL UNIQUE,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('standard', 'admin', 'employee') NOT NULL DEFAULT 'standard',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `account_number` BIGINT(20) UNSIGNED NOT NULL,
    `balance` DECIMAL(10,2) NOT NULL DEFAULT 1000.00,
    `isactive` TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`)
);

-- Insert data into users table
INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `updated_at`, `account_number`, `balance`, `isactive`)
VALUES
(12, 'employee', 'employee@gmail.com', '$2y$10$H2huLi1aIZy1fVJPU882Q.jANzUEetPzmeno5lVAY89folDYzU4tq', 'employee', '2025-01-02 12:22:23', '2025-01-02 12:57:47', 202500000, 1000.00, 1),
(13, 'admin', 'admin@gmail.com', '$2y$10$MlGmoxkwZf3ESIEfYFTb0O6AZnaFrvjp8QNomtM/Oc0gbG8I3vhDq', 'admin', '2025-01-02 12:22:38', '2025-01-02 12:44:13', 202500001, 1000.00, 1),
(14, 'backup', 'backupadmin@gmail.com', '$2y$10$iYa25ZJALke00YVNTPOFx.qf3zq5Tel.YITrMzPm5QVpPGGK/MjUS', 'admin', '2025-01-02 12:45:19', '2025-01-02 12:45:19', 202500002, 1000.00, 1),
(15, 'administrator', 'administrator@gmail.com', '$2y$10$R6Axpglk90kYPJ4OYe/mZ.bzWJ9b0qkLZKxJHmCruq5QEdTfgpIXq', 'admin', '2025-01-02 12:51:25', '2025-01-02 12:51:25', 202500003, 1000.00, 1),
(17, 'backupmanager', 'backupmanager@gmail.com', '$2y$10$r2Tl1351NVpOVVw7nImHuea5PHL5i8ee4EgTvXkU8ykfiyqfoznqy', 'admin', '2025-01-02 12:56:47', '2025-01-02 12:58:04', 202500004, 1000.00, 1);

-- Table for Fixed Deposits
CREATE TABLE `fixed_deposits` (
    `fd_id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) NOT NULL,
    `account_number` BIGINT(20) UNSIGNED NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `tenure` INT(11) NOT NULL,
    `interest_rate` DECIMAL(5,2) NOT NULL,
    `maturity_date` DATE NOT NULL,
    `status` ENUM('Active', 'Matured') DEFAULT 'Active',
    `applied_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`fd_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
);

-- Table for Messages
CREATE TABLE `messages` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `phone_number` VARCHAR(20) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `description` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
);

-- Table for Password Resets
CREATE TABLE `password_resets` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(255) NOT NULL,
    `token` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `expires_at` TIMESTAMP NULL,
    PRIMARY KEY (`id`)
);

-- Table for Service Requests
CREATE TABLE `service_requests` (
    `service_id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) NOT NULL,
    `account_number` BIGINT(20) UNSIGNED NOT NULL,
    `status` ENUM('In Progress', 'Completed', 'Failed') DEFAULT 'In Progress',
    `reason` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `attachment_link` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`service_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
);

-- Table for Transactions
CREATE TABLE `transactions` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) NOT NULL,
    `transaction_type` ENUM('debit', 'credit') NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `balance_after` DECIMAL(10,2) NOT NULL,
    `transaction_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `destination_account` BIGINT(20) UNSIGNED DEFAULT NULL,
    `source_account` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
);

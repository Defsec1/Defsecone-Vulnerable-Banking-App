<?php
session_start(); // Start the session to retrieve user data

// Database connection
$host = 'db';
$dbname = 'webserver';
$dbusername = 'wp_user';
$dbpassword = 'your_password';
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Error and success messages
$error_message = '';
$success_message = '';

// Fetch logged-in user data
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Logged-in user ID
$sql_user = "SELECT * FROM users WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param('i', $user_id);
$stmt_user->execute();
$user_result = $stmt_user->get_result();

if ($user_result->num_rows > 0) {
    $user = $user_result->fetch_assoc();
} else {
    die("User not found.");
}

// Handle form submission for fixed deposit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get POST data
    $amount = $_POST['amount'];
    $tenure = $_POST['tenure'];
    $interest_rate = $_POST['interest_rate'];
    $account_number = $user['account_number'];

    // Validate inputs
    if (empty($amount) || empty($tenure) || !is_numeric($amount) || !is_numeric($tenure) || !is_numeric($interest_rate)) {
        $error_message = 'Please provide valid amount, tenure, and interest rate.';
    } else if ($user['balance'] < $amount) {
        $error_message = 'Insufficient balance for this fixed deposit.';
    } else {
        // Calculate maturity date by adding tenure months to the current date
        $date = new DateTime();
        $date->modify("+$tenure months");
        $maturity_date = $date->format('Y-m-d');

        // Begin transaction (for consistency)
        $conn->begin_transaction();

        try {
            // Debit the source account balance for fixed deposit
            $new_balance = $user['balance'] - $amount;
            $sql_debit_balance = "UPDATE users SET balance = ? WHERE id = ?";
            $stmt_debit_balance = $conn->prepare($sql_debit_balance);
            $stmt_debit_balance->bind_param('di', $new_balance, $user_id);
            if (!$stmt_debit_balance->execute()) {
                throw new Exception("Failed to update account balance.");
            }

            // Insert into fixed_deposits table
            $sql_fd = "INSERT INTO fixed_deposits (user_id, account_number, amount, tenure, interest_rate, maturity_date, status)
                        VALUES (?, ?, ?, ?, ?, ?, 'Active')";
            $stmt_fd = $conn->prepare($sql_fd);
            $stmt_fd->bind_param('isdiis', $user_id, $account_number, $amount, $tenure, $interest_rate, $maturity_date);
            if (!$stmt_fd->execute()) {
                throw new Exception("Failed to create fixed deposit.");
            }

            // Insert into service_requests table with status 'In Progress'
            $reason = 'Fixed Deposit';
            $sql_service_request = "INSERT INTO service_requests (user_id, account_number, status, reason) 
                                    VALUES (?, ?, 'In Progress', ?)";
            $stmt_service_request = $conn->prepare($sql_service_request);
            $stmt_service_request->bind_param('iss', $user_id, $account_number, $reason);
            if (!$stmt_service_request->execute()) {
                throw new Exception("Failed to create service request.");
            }

            // Commit the transaction
            $conn->commit();
            $success_message = 'Fixed deposit created successfully, and service request is in progress!';
        } catch (Exception $e) {
            // Rollback the transaction in case of an error
            $conn->rollback();
            $error_message = 'Error: ' . $e->getMessage();
        }
    }
}

// Fetch current fixed deposits
$sql_deposits = "SELECT * FROM fixed_deposits WHERE user_id = ? ORDER BY maturity_date DESC";
$stmt_deposits = $conn->prepare($sql_deposits);
$stmt_deposits->bind_param('i', $user_id);
$stmt_deposits->execute();
$result_deposits = $stmt_deposits->get_result();

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fixed Deposit</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #003366;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 30px;
            box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar h3 {
            color: #fff;
            text-align: center;
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 12px 20px;
            text-decoration: none;
            border-bottom: 1px solid #ccc;
        }

        .sidebar a:hover {
            background-color: #00509E;
        }

        .main-content {
            margin-left: 270px;
            padding: 20px;
            width: calc(100% - 270px);
        }

        .container {
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        .message {
            padding: 10px;
            background-color: #ffcccc;
            color: #e60000;
            margin-bottom: 20px;
        }

        .success-message {
            background-color: #ccffcc;
            color: #006600;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            background-color: #003366;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #002244;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3>Dashboard</h3>
    <a href="dashboard.php">Home</a>
    <a href="fundtransfer.php">Fund Transfer</a>
    <a href="fixeddeposit.php">Fixed Deposit</a>
    <a href="applydebitcard.php">Apply Debit Card</a>
    <a href="applycreditcard.php">Apply Credit Card</a>
    <a href="checkbalance.php">Check Balance</a>
    <a href="accountstatement.php">Account Statement</a>
    <a href="blockcard.php">Block Card</a>
    <a href="servicerequest.php">Service Request</a>
  </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <h2>Create Fixed Deposit</h2>

            <!-- Error or Success Messages -->
            <?php if ($error_message): ?>
                <div class="message"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <?php if ($success_message): ?>
                <div class="message success-message"><?php echo $success_message; ?></div>
            <?php endif; ?>

            <!-- Form for Fixed Deposit -->
            <form action="fixeddeposit.php" method="POST">
                <div class="form-group">
                    <label for="amount">Amount</label>
                    <input type="number" name="amount" id="amount" required>
                </div>
                <div class="form-group">
                    <label for="tenure">Tenure (Months)</label>
                    <input type="number" name="tenure" id="tenure" required>
                </div>
                <div class="form-group">
                   <input type="hidden" name="interest_rate" id="interest_rate" value="6" required readonly>
                </div>

                <button type="submit">Create Fixed Deposit</button>
            </form>

            <h3>Your Current Fixed Deposits</h3>
            <table>
                <tr>
                    <th>Amount</th>
                    <th>Tenure (Months)</th>
                    <th>Interest Rate (%)</th>
                    <th>Maturity Date</th>
                    <th>Status</th>
                </tr>
                <?php while ($deposit = $result_deposits->fetch_assoc()): ?>
                    <tr>
                        <td>₹<?php echo number_format($deposit['amount'], 2); ?></td>
                        <td><?php echo $deposit['tenure']; ?> months</td>
                        <td><?php echo $deposit['interest_rate']; ?>%</td>
                        <td><?php echo $deposit['maturity_date']; ?></td>
                        <td class="status-in-progress"><?php echo $deposit['status']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </div>
</body>
</html>
